/* SPDX-License-Identifier: GPL-3.0-only. Test real PC7 setup against register-backed fake silicon. */
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../firmware/hal/fm1_gpio.h"
static uint32_t regs[0x60000/4],before[0x60000/4];
#undef FM1_PR
#define FM1_PR(p,r) regs[(FM1_PORT(p)+(r))/4]
#define SMK_UART_REG(a) regs[(a)/4]
#define SMK_UART_BARRIER() ((void)0)
#include "../firmware/hal/smk_uart_tx.h"
static void ok(int n,const char*s){if(!n){fprintf(stderr,"FAIL %s\n",s);exit(1);}}
int main(void){
 for(unsigned i=0;i<sizeof regs/sizeof regs[0];i++)regs[i]=0xAAAAAAAAu;memcpy(before,regs,sizeof regs);
 smk_uart_tx_init();
 ok(regs[0x12108/4]==383&&regs[0x12100/4]==0x3401&&regs[0x12104/4]==0,"31250 baud, enabled TX, no RX/DMA/interrupt enables");
 ok((regs[0x10010/4]&(3u<<10))==(1u<<10),"UART uses PLL48M");
 ok((regs[0x51028/4]&((15u<<20)|128u))==(1u<<20),"PC7 UART1 output routing");
 ok((FM1_PR(FM1_PC,FM1_PU)&128u)&&(FM1_PR(FM1_PC,FM1_PD)&128u)&&(FM1_PR(FM1_PC,FM1_DIE)&128u)&&!(FM1_PR(FM1_PC,FM1_DIR)&128u)&&!(FM1_PR(FM1_PC,FM1_OUT)&128u),"stock PC7 electrical configuration");
 for(unsigned i=0;i<sizeof regs/sizeof regs[0];i++){
  unsigned a=i*4;
  if(a==0x10010||a==0x51028||a==0x12100||a==0x12104||a==0x12108||a==0x50080||a==0x50088||a==0x5008C||a==0x50090||a==0x50094)continue;
  ok(regs[i]==before[i],"all other registers, including PH8 and display registers, unchanged");
 }
 const unsigned off[]={FM1_OUT,FM1_DIR,FM1_DIE,FM1_PU,FM1_PD};for(unsigned i=0;i<5;i++)ok((FM1_PR(FM1_PC,off[i])&~128u)==(before[(FM1_PORT(FM1_PC)+off[i])/4]&~128u),"other PC pins retained");
 regs[0x12100/4]|=0x8000;ok(smk_uart_tx_done(),"TX completion flag observed");smk_uart_tx_byte(0x90);ok(regs[0x1210C/4]==0x90&&(regs[0x12100/4]&0x2000),"byte send clears TPND and writes BUF");
 puts("SMK_UART_HAL_PASS: stock PC7 routing/baud/polarity, no PH8 or other-pin writes, TX pending and byte send");return 0;
}
