# SPDX-License-Identifier: GPL-3.0-only
# Transport simulator adapted from Felucca install_test.py (Leo Kuroshita).
import sys,io,queue,threading,time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'tools'))
import smk37_install as I
I.DELAY.update(open=0,start=.01,reply=0,loader=.01,reboot=.01,retry=.02,poll=.05,hs=.1,idle_check=.4,idle_write=.4,wait_loader=2,wait_reboot=2)
class FakeLink:
    def __init__(self, dev, gen):
        self.dev, self.gen, self.q, self.closed = dev, gen, queue.Queue(), False

    @property
    def lost(self):
        return self.gen != self.dev.gen or not self.dev.connected

    def send(self, pkt):
        if self.lost:
            return False
        self.dev.sent.append(bytes(pkt))
        self.dev.rx(bytes(pkt))
        return True

    def read(self, timeout):
        try:
            return self.q.get(timeout=max(timeout, 0))
        except queue.Empty:
            return None

    def drain(self):
        while not self.q.empty():
            self.q.get_nowait()

    def close(self):
        self.closed = True


class FakeFM1:
    """a MIDI backend with one FM-1 on it"""

    def __init__(self, image, identity="SMK-37 Pro_016", name="SMK-37 Pro", unplug_after=None, after_write="SMK-37 Pro_9748028",
                 stall_after=None, bad_addr=None, loader_name="Felucca Update", after_name="Felucca"):
        self.image, self.unplug_after, self.after_write = image, unplug_after, after_write
        self.loader_name, self.after_name = loader_name, after_name
        self.stall_after, self.bad_addr = stall_after, bad_addr
        self.served = self.bad = self.upgrades = 0
        self.sent, self.links, self.gen, self.lock = [], [], 0, threading.Lock()
        self.boot(identity, name)

    def boot(self, identity, name):
        with self.lock:
            self.gen += 1
            self.identity, self.name, self.connected = identity, name, True
            self.waiting, self.queue = None, []

    def input_names(self):
        return [self.name] if self.connected else []

    output_names = input_names

    def open(self, in_name, out_name):
        if in_name != self.name or not self.connected:
            raise IOError("no such port")
        link = FakeLink(self, self.gen)
        self.links.append(link)
        return link

    def tx(self, pkt):
        for link in self.links:
            if link.gen == self.gen and not link.closed:
                link.q.put(bytes(pkt))

    def rx(self, d):
        if d == I.HS_QUERY:
            t = self.identity.encode()
            self.tx(b"\xF0" + I.pack7(bytes([0, 0x59, 0x11, 0, 0, 0]) + t + bytes(28 - len(t))) + b"\xF7")
        elif d == I.UPGRADE:
            self.upgrades += 1
            first = self.bad_addr if self.bad_addr is not None else 0
            self.queue = ([(first + k * 512, 512) for k in range(6)] + [(I.FINISH_WRITE, 8)]
                          if self.identity.startswith("ota-")
                          else [(0, 64), (0x40, 160), (0x1000, 512), (I.FINISH_CHECK, 8)])
            self.next()
        elif self.waiting:
            u = I.unpack7(d[1:-1])
            addr, n = self.waiting
            fin = addr >= I.FINISH_CHECK
            want = b"success\0" if fin else self.image[addr:addr + n]
            if u[14:14 + len(want)] != want or len(u) != 15 + len(want):
                self.bad += 1
            self.waiting = None
            self.served += 1
            if self.unplug_after and self.served >= self.unplug_after:
                self.connected = False
                return
            if self.stall_after and self.served >= self.stall_after:
                return
            if addr == I.FINISH_CHECK:
                threading.Timer(0.05, self.boot, ("ota-SMK-37 Pro_9748028", self.loader_name)).start()
            elif addr == I.FINISH_WRITE:
                threading.Timer(0.05, self.boot, (self.after_write, self.after_name)).start()
            else:
                self.next()

    def next(self):
        if not self.queue:
            return
        self.waiting = addr, n = self.queue.pop(0)
        u = bytearray([0, 0x59, 0x30, 0, 0, 0, 0]) + addr.to_bytes(4, "little") + bytes([n & 0xFF, n >> 8, 0])
        u.append(~sum(u[6:14]) & 0xFF)
        self.tx(b"\xF0" + I.pack7(u) + b"\xF7")



def cli(args,dev,answer=True):
 out,err=io.StringIO(),io.StringIO();old=sys.stderr;sys.stderr=err
 try: rc=I.main(args,backend=dev,out=out,ask=lambda _:answer)
 finally:sys.stderr=old
 return rc,out.getvalue(),err.getvalue()
p='/Volumes/SSD/Development/BuildCache/jazzy-smk37/20261126/smk37/firmware/felucca-0.1.0-smk3.fwsc'
prod,image=I.load_package(p,False)
def test(name,args,dev,want,upgrades=None,answer=True):
 rc,out,err=cli(args,dev,answer)
 assert rc==want and (upgrades is None or dev.upgrades==upgrades),(name,rc,out,err,dev.upgrades)
 print('PASS',name);return dev
test('stock -> custom loader -> verified app',[p,'--yes'],FakeFM1(image),0,2)
test('already in loader resumes',[p,'--yes'],FakeFM1(image,identity='ota-'+prod,name='RHYTHMER Update'),0,1)
test('cancel sends no upgrade',[p],FakeFM1(image),1,0,False)
test('FM-1 refused before entering upgrade',[p,'--yes'],FakeFM1(image,identity='FM-1_900'),6,0)
test('Elite refused before entering upgrade',[p,'--yes'],FakeFM1(image,identity='SMK-37 Elite_016'),6,0)
test('disconnect during write reports failure',[p,'--yes'],FakeFM1(image,identity='ota-'+prod,name='RHYTHMER Update',unplug_after=3),4)
test('wrong identity after reboot reports failure',[p,'--yes'],FakeFM1(image,after_write='SMK-37 Pro_016'),6)
test('JAZZY named ports stay discoverable',[p,'--yes'],FakeFM1(image,name='JAZZY',after_name='JAZZY',loader_name='JAZZY Update'),0,2)
d=test('backup prepares loader, no app write',[p,'--yes','--prepare-backup'],FakeFM1(image),0,1)
assert bytes.fromhex('F0 22 24 35 7D F7') in d.sent
print('SMK_INSTALLER_PASS: successful install/resume, cancellation, model guards, disconnect, identity and backup-only flow')
