#!/usr/bin/env python3
"""SSD-only isolated JAZZY SMK build; --board fm1 verifies the original target."""
from pathlib import Path
import os,sys,shutil,subprocess,argparse
ROOT=Path(__file__).resolve().parents[1]
a=argparse.ArgumentParser();a.add_argument('--board',choices=['smk37','fm1'],default='smk37');a=a.parse_args()
if not os.path.ismount('/Volumes/SSD'):raise SystemExit('Reconnect the configured SSD')
job=Path('/Volumes/SSD/Development/BuildCache/jazzy-smk37/20261126')/('smk37'if a.board=='smk37'else'fm1-check')
subprocess.run(['/Users/dave/.local/share/ssd-development/bin/ssd-qa-output',str(job)],check=True)
source=job/'source';out=job/'firmware'
shutil.copytree(ROOT,source,dirs_exist_ok=True,ignore=shutil.ignore_patterns('build','build-*','.git','__pycache__','*.orig','*.rej'))
t=Path('/Volumes/SSD/Development/Toolchains/fm1-six-tooling')
env={**os.environ,'PATH':str(t/'bin')+':/usr/bin:/bin:/usr/sbin:/sbin','TMPDIR':'/Volumes/SSD/Development/Caches/rhythmer/tmp','PYTHONPYCACHEPREFIX':'/Volumes/SSD/Development/Caches/rhythmer/python','PYTHON':str(t/'python/bin/python3'),'JIELI_NERDCTL':'1','JIELI_TOOLCHAIN':str(t/'jieli/toolchain'),'JIELI_GUEST_TOOLCHAIN':'/Volumes/SSD/fm1-six-tooling/jieli/toolchain','AC79_SDK':str(t/'fw-AC79_AIoT_SDK'),'RHYTHMER_BUILD_DIR':str(out),'BOARD':a.board}
cmd=['sh',str(source/'build.sh')]
if a.board=='smk37':cmd+=['--release','0.1.0-beta.1']
raise SystemExit(subprocess.call(cmd,env=env))
