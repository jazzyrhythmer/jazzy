# JAZZY OS · SMK-37 Pro 테스트 후보

버전: **0.1.0-smk3** / 설치 후 ID: **SMK-37 Pro_9748028**

기존 FM-1용과 별도 빌드인 SMK-37 Pro 테스트 후보입니다. 실기기에 자동 설치하지 않습니다.
빌드·자동 검증은 통과했으며, 아래 절차로 직접 실기기 테스트할 수 있습니다.

## 먼저 확인

- **SMK-37 Pro 공식 1.16 (=v016)**의 배선·저장 배치를 기준으로 준비했습니다. 기기 화면의 **1.16**과 같은 버전입니다. `--info`로 연결된 기기의 ID를 확인해 주세요.
- 첫 설치 시 프로젝트/설정 영역을 새로 초기화하고, 사용자 샘플 영역에는 두 Break 뱅크가 들어갑니다. **원본 1 MiB 플래시를 두 번 읽어 동일한지 확인한 뒤 설치하세요.**
- 보정값·기기 키·Bluetooth 데이터·공식 리소스 영역은 커스텀 로더의 쓰기 대상에서 제외했습니다.
- Rhythmer ↔ Jazzy 전환 시 두 OS가 같은 저장 영역을 사용하므로, 이전 OS의 프로젝트를 함께 보존하는 구조가 아닙니다. 테스트할 파일 하나를 먼저 선택하세요.

## 브라우저에서 간단 설치

전체 플래시 백업을 먼저 저장·검증한 뒤 [JAZZY SMK-37 Pro 설치기](https://jazzyrhythmer.github.io/jazzy/installer/?board=smk37)를 컴퓨터의 Chrome 또는 Edge에서 엽니다.

1. 한 대만 USB 데이터 케이블로 연결하고, 다른 MIDI 앱을 닫습니다.
2. 첫 화면의 백업·데이터 변경·주의사항 세 항목을 확인하고 **INSTALL**을 한 번 누릅니다.
3. 브라우저가 요청하면 MIDI 접근을 허용합니다. 기기 확인 → 지원되는 OS의 음악 백업 다운로드 요청 → 전송 → 재시작 후 검증이 자동으로 이어집니다.
4. 오류가 나오면 진단 보고서를 저장합니다. 다른 기종, 손상된 파일, 실패한 음악 백업은 전송 전에 중단합니다.

공식 1.16과 업데이트 로더는 브라우저 음악 백업을 제공하지 않습니다. 첫 설치용 전체 플래시 백업은 아래 `SMK37.md` 절차가 필요합니다. 브라우저가 다운로드 저장을 막으면 표시된 백업 링크에서도 받을 수 있습니다.

## 터미널로 설치 (Mac)

압축을 SSD에 풀고 그 폴더에서 터미널을 엽니다.

```sh
python3 -m venv /Volumes/SSD/Development/Toolchains/smk37-installer
/Volumes/SSD/Development/Toolchains/smk37-installer/bin/pip install --cache-dir /Volumes/SSD/Development/Caches/pip mido python-rtmidi
/Volumes/SSD/Development/Toolchains/smk37-installer/bin/python smk37_install.py --info
```

1. DAW와 MIDI 앱을 닫고 USB 데이터 케이블로 직접 연결합니다.
2. `SMK37.md`의 **Full flash backup** 절차를 먼저 진행합니다. `--prepare-backup`은 앱 영역 설치를 시작하지 않고 백업용 UBOOT 진입만 요청합니다. 원시 플래시 읽기는 Linux 또는 관리자 권한 Windows가 필요합니다.
3. 두 덤프를 `python smk37_verify_backup.py dump1.bin dump2.bin`으로 확인합니다.
4. 전원을 다시 켠 뒤 다음 명령으로 설치합니다. 로더 모드로 남아 있어도 같은 파일로 진행할 수 있습니다.

```sh
/Volumes/SSD/Development/Toolchains/smk37-installer/bin/python smk37_install.py JAZZY-OS-SMK37-Pro-0.1.0-smk3.fwsc
```

5. 표시된 기종을 확인하고 승인한 뒤, 쓰기·재시작·최종 ID 확인까지 기다립니다.
6. `SMK37.md`의 **Hardware test checklist** 순서로 확인하고 결과를 알려주세요.

## 기본 조작

| 기기 표기 | 동작 |
|---|---|
| K1 / K2 / K3 / K4 | 마스터 / 페이지 선택 / 트랙 선택 / 프리셋 |
| K5–K8 | 화면의 파라미터 4개 |
| PATCH / PARA | HOME(길게 Menu) / EDIT |
| CHORD / NOTE REPEAT | ENV / LFO |
| BT | SAVE·프로젝트 화면 |
| KNOB BANK | 패드 PLAY ↔ STEPS |
| FADER BANK | LEVEL → PAN → REVERB → DELAY |
| OCTAVE − / + | 기존 옥타브·취소/확인 기능 |

패드 번호는 **윗줄 1–8, 아랫줄 9–16**입니다. STEPS는 현재 16스텝 구간을 편집합니다.
페이더는 트랙 1–4, 또는 트랙 5/6 선택 시 페이더 1/2로 트랙 5–6을 조절합니다. 저장된 값에 닿아야 움직이기 시작하는 픽업 방식입니다.

## 꼭 테스트할 항목

37개 건반의 음정·강약·노트 종료 → 16패드와 LED/스텝 위치 → 페이더 네 뱅크와 픽업 → 프리셋/편집/GEN/Break → 프로젝트 저장 후 전원 재시작·복원 → 밀도 높은 패턴의 장시간 재생.

**TRS MIDI OUT을 추가했습니다.** USB 연결 없이도 동봉 변환 케이블로 외부 악기를 연주할 수 있습니다. 트랙 1–6은 MIDI 채널 1–6으로 출력합니다.

PATCH를 길게 눌러 Menu → CONTROL → MIDI OUT에서 **KEYS**(건반·코드·휠), **CLOCK**(건반과 내부 클록·시작/정지), **ALL**(시퀀서·아르페지오 포함), **OFF**를 선택하세요. 외부 악기만 들으려면 트랙 LEVEL을 내립니다. 트랙 MUTE는 시퀀서 MIDI도 차단합니다.

먼저 USB 없이 건반·코드·패턴과 Stop을 시험하고, 다음으로 USB MIDI/오디오와 동시에 사용해 주세요. 실제 잭 신호·케이블 배선·타이밍 확인이 필요합니다.

**풋페달 서스테인과 Bluetooth MIDI는 이번 후보에 포함되지 않았습니다.** 실제 키/패드 감도, 출력·USB 안정성은 실기기 확인이 남아 있습니다.

공식 복구 파일의 링크·검증값과 중단 시 복구 방법은 `SMK37.md`에 있습니다. `Source.tar.gz`에는 이 설치 파일에 대응하는 소스와 생성 입력을 넣었습니다. `VALIDATION.json`은 소프트웨어 검증 내역입니다.
