#define BOARD_SMK37 1
#include "../firmware/hal/fm1_flash_map.h"
/* Real external-asset path and original integer-table/program parity. */
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#define JAZZY_EXTERNAL_ASSETS 1
#define UI_TEST_NO_MAIN 1
static uint8_t asset_flash[1<<20];
static const uint8_t *fm1_xip_ptr(uint32_t off){return asset_flash+off;}
#include "jazzy_host.h"
#include "../firmware/jazzy/hydra_expect.h"
static int st_read(uint32_t off,void *dst,uint32_t n){memcpy(dst,asset_flash+off,n);return 0;}
static int st_erase(uint32_t off){memset(asset_flash+off,255,4096);return 0;}
static int st_prog(uint32_t off,const void *p,uint32_t n){memcpy(asset_flash+off,p,n);return 0;}
#include "../firmware/src/storage.c"
#include "../firmware/src/synth_assets.c"
static uint32_t hash(const void *p,unsigned n){const uint8_t *b=p;uint32_t h=2166136261u;while(n--)h=(h^*b++)*16777619u;return h;}
static uint32_t play(unsigned e,unsigned pi,unsigned macro,int value){
 track_t *t=&trk[0];set_engine_of(t,e);apply_preset_to(t,pi);t->engine=t->eng_req;t->p[P_E0+macro]=(int16_t)value;
 memset(t->v,0,sizeof t->v);voice_t *v=&t->v[0];v->active=v->gate=1;v->note=60;v->pitch16=960;v->vel=110;v->env_out=32767;
 const engine_t *en=ENGINES[e];if(en->block)en->block(t);en->note_on(t,v);
 vmod_t m={0};m.inc=pitch_inc(960);m.pitch16=960;m.amp0=m.amp1=24576;m.envq15=32767;m.shape=16384;
 uint32_t h=2166136261u;for(unsigned j=0;j<120;j++){int32_t o[CTL]={0};if(en->block)en->block(t);en->render(t,v,o,CTL,&m);h=(h^hash(o,sizeof o))*16777619u;}return h;
}
static int expansion_cases(int argc,char **argv){
 unsigned bad=0;uint8_t p[32];if(argc!=8&&argc!=9)return 2;
 for(unsigned i=0;i<2;i++){FILE *f=fopen(argv[i+1],"rb");if(!f||fread(asset_flash+0xC2000+i*0x14000,1,81920,f)!=81920)return 2;fclose(f);}
 for(unsigned i=0;i<3;i++){
  FILE *f=fopen(argv[i+3],"rb");
  if(!f||fread(asset_flash+JCAT_PARTS[i].at,1,JCAT_PARTS[i].size,f)!=JCAT_PARTS[i].size)return 2;
  fclose(f);
 }
 FILE *font=fopen(argv[6],"rb");
 if(!font||fread(asset_flash+JAZZY_FONT_AT,1,AF_M_XIP_BYTES,font)!=AF_M_XIP_BYTES)return 2;
 fclose(font);
 FILE *marker=fopen(argv[7],"rb");
 if(!marker||fread(asset_flash+0xEB020u,1,LXR_MARKER_BYTES,marker)!=LXR_MARKER_BYTES)return 2;
 fclose(marker);
 FILE *lxr=argc==9?fopen(argv[8],"rb"):NULL;
 if(argc==9&&!lxr)return 2;
 bad+=check("external factory catalog and font checksums valid",jazzy_catalog_check()&&jazzy_font_valid);
 asset_flash[JAZZY_FONT_AT]^=1;
 bad+=check("bad font triggers fallback with catalog still available",jazzy_catalog_check()&&!jazzy_font_valid);
 cv_begin(240, 60, 0);
 cv_text(10, 5, &AF_M, "azimuth", 65535);
 asset_flash[JAZZY_FONT_AT]^=1;
 bad+=check("restored font validates",jazzy_catalog_check()&&jazzy_font_valid);
 bad+=check("factory rows decode on both sides of both boundaries",fp_unpack(15)&&fp_unpack(16)&&fp_unpack(23)&&fp_unpack(24));
 for(unsigned i=0;i<3;i++){
  asset_flash[JCAT_PARTS[i].at]^=1;
  bad+=check("bad factory resource is detected before decoding",!jazzy_catalog_check()&&!fp_unpack(0));
  asset_flash[JCAT_PARTS[i].at]^=1;
  bad+=check("restored catalog validates",jazzy_catalog_check());
 }
 bad+=check("LXR marker and catalog assets validate",lxr_assets_valid);
 asset_flash[0xEB020u]^=1;
 bad+=check("bad LXR marker is isolated from synth catalog and font",jazzy_catalog_check()&&!lxr_assets_valid&&jazzy_font_valid);
 asset_flash[0xEB020u]^=1;
 bad+=check("restored LXR bank validates",jazzy_catalog_check()&&lxr_assets_valid);
 unsigned lxr_differences=0;
 uint32_t lxr_hash=2166136261u;
 for(unsigned i=0;i<LXR_COUNT;i++){
  lxr_patch_t got,expected;
  lxr_unpack(&got,i);
  if(lxr){
   if(fread(&expected,1,sizeof expected,lxr)!=sizeof expected)return 2;
   lxr_differences+=memcmp(&got,&expected,sizeof got)!=0;
  }
  for(unsigned k=0;k<sizeof got;k++)lxr_hash=(lxr_hash^((const uint8_t*)&got)[k])*16777619u;
  lxr_differences+=!lxr_factory(i)->name[0];
 }
 if(lxr)fclose(lxr);
 bad+=check("595 LXR voices round-trip from the upstream projection",LXR_COUNT==595u&&!lxr_differences&&lxr_hash==0x18a8b620u);
 bad+=check("bank-tail checksums valid",jazzy_assets_check());ui_power_on();fm6_init();power_on_parts();song.playing=0;transport_req=0;chain.armed=0;
 unsigned mismatch=0;
 for(unsigned i=0;i<4096;i++)mismatch+=jv_lookup(i)!=FM106_VCF_G1[i];
 for(unsigned i=0;i<1025;i++)mismatch+=jt_lookup(&JT_EXP,i)!=FM6_EXP2[i];
 for(unsigned i=0;i<769;i++)mismatch+=jt_lookup(&JT_M2,i)!=m2_T_INC_TOP[i];
 for(unsigned i=0;i<768;i++)mismatch+=jt_lookup(&JT_KW,i)!=jk_KS_PITCH[i];
 bad+=check("6658 original table values match exactly",mismatch==0);
 mismatch=0;for(unsigned i=0;i<200;i++){jf_load(p,i);mismatch+=memcmp(p,FMINI_FACTORY[i],32)!=0;}
 bad+=check("all 6400 FMini native bytes match",mismatch==0);
 /* The off-chip compressed stream must decode identically to the independently
  * generated inline source, across the physical slot boundary. */
 for(unsigned i=0;i<sizeof JH_WAVE_PACK;i++)mismatch+=jh_pack_get(i)!=JH_WAVE_PACK[i];
 bad+=check("split physical HYDRA stream matches",mismatch==0);
 uint32_t wavehash=hash(jh_waves,sizeof jh_waves);printf("HYDRA wave FNV=%u\n",wavehash);bad+=check("all 12288 native wave bytes match",wavehash==JH_WAVE_EXPECT);
 static const unsigned models[]={ENGI_S1,ENGI_HYDRA};
 for(unsigned j=0;j<2;j++){
  unsigned e=models[j],pi=j?15:47;track_t *t=&trk[0];set_engine_of(t,e);apply_preset_to(t,pi);t->engine=e;t->p[P_E2]=31;t->p[P_E6]=12;
  int16_t saved[P_COUNT];memcpy(saved,t->p,sizeof saved);song.sel=0;
  bad+=check("new model user preset stores",up_store(j,"EXPANSION")==3);set_engine_of(t,ENGI_ANALOG);up_load(j);
  bad+=check("native program and macros survive user preset",t->eng_req==e&&t->p[P_LN0]==saved[P_LN0]&&t->p[P_E2]==31&&t->p[P_E6]==12);
  bad+=check("expansion project saves",project_save(j)==0);set_engine_of(t,ENGI_ANALOG);project_load(j);
  bad+=check("native program survives project",t->eng_req==e&&t->p[P_LN0]==saved[P_LN0]&&t->p[P_E2]==31&&t->p[P_E6]==12);
 }
 bad+=check("S1 DRAW multiplier reaches native DSP",play(ENGI_S1,42,6,0)!=play(ENGI_S1,42,6,20));
 bad+=check("S1 CHOP reaches native DSP",play(ENGI_S1,3,7,0)!=play(ENGI_S1,3,7,100));
 unsigned changes=0;for(unsigned pi=0;pi<16;pi++)for(unsigned k=0;k<8;k++)changes+=play(ENGI_HYDRA,pi,k,-64)!=play(ENGI_HYDRA,pi,k,63);
 bad+=check("HYDRA factory macro routes affect sound",changes>=80);printf("HYDRA audible macro comparisons=%u/128\n",changes);
 /* Exercise union reuse at high preset IDs; a previous model's bytes must not
  * be mistaken for a valid prepared HYDRA part. */
 uint32_t expected=play(ENGI_HYDRA,0,0,0);
 for(unsigned i=0;i<24;i++){play(i&1?ENGI_FM6:ENGI_PROPHET,0,0,60);bad+=check("FM6 / Prophet / HYDRA storage switching stable",play(ENGI_HYDRA,0,0,0)==expected);}
 unsigned flips[]={0,8175,8176,16089};for(unsigned i=0;i<4;i++){uint8_t *b=(uint8_t*)jazzy_asset_at(flips[i]);*b^=1;bad+=check("asset corruption detected",!jazzy_assets_check());bad+=check("bad asset bank prevents new model selection",!eng_ok(ENGI_S1)&&!eng_ok(ENGI_HYDRA));*b^=1;bad+=check("restored asset bank validates",jazzy_assets_check());}
 printf("expansion failures=%u\n",bad);return !!bad;
}

#include "jazzy_factory_expect.h"
static unsigned failures;
#define REQ(s,x) do{if(!(x)){printf("FAIL %s e=%u p=%u\n",s,e,k);failures++;}}while(0)
static unsigned hashbyte(unsigned h,unsigned x){return (h^(x&255u))*16777619u;}
static int factory_cases(void){
 ui_power_on();fm6_init();power_on_parts();
 uint8_t settings_before[32],crash_before[32],learn_before[32];
 memset(&favorites,0,sizeof favorites);memset(favorites.factory[15],0x53,32);memset(favorites.factory[13],0x26,32);memset(favorites.factory[1],0x37,32);
 memcpy(settings_before,favorites.factory[15],32);memcpy(crash_before,favorites.factory[13],32);memcpy(learn_before,favorites.factory[1],32);
 unsigned checked=0,starred=0;
 for(unsigned j=0;j<NENG_SHOWN;j++){
  unsigned e=ENGINE_ORDER[j],k=0;if(e==ENGI_EMPTY)continue;const engine_t *en=ENGINES[e];
  REQ("legacy stars fit protected prefix",e>=22||en->npresets<=128);
  for(k=0;k<en->npresets;k++){REQ("star starts clear",!favorite_has(e,k));REQ("star set",favorite_set(e,k,1));REQ("star stays set",favorite_has(e,k));starred++;}
 }
 for(unsigned j=0;j<NENG_SHOWN;j++){unsigned e=ENGINE_ORDER[j];if(e==ENGI_EMPTY)continue;for(unsigned k=0;k<ENGINES[e]->npresets;k++){REQ("star survives other engines",favorite_has(e,k));favorite_set(e,k,0);}}
 {unsigned e=0,k=0;REQ("settings preserved",!memcmp(settings_before,favorites.factory[15],32));REQ("crash preserved",!memcmp(crash_before,favorites.factory[13],32));REQ("MIDI learn preserved",!memcmp(learn_before,favorites.factory[1],32));}
 memset(&favorites,0,sizeof favorites);
 for(unsigned q=0;q<NELEM(FP_EXPECT);q++){
  unsigned e=FP_EXPECT[q][0],k=FP_EXPECT[q][1];const engine_t *en=ENGINES[e];track_t *t=&trk[0];set_engine_of(t,e);unsigned sig=steps_sig(t);apply_preset_to(t,k);const preset_t *p=factory_preset(en,k);
  unsigned h=2166136261u;for(unsigned i=0;i<16;i++)h=hashbyte(h,i<strlen(p->name)?p->name[i]:0);
  for(unsigned i=0;i<8;i++){h=hashbyte(h,p->e[i]);REQ("macro loaded within declared range",t->p[P_E0+i]>=en->edit[i].min&&t->p[P_E0+i]<=en->edit[i].max);REQ("macro value applied",t->p[P_E0+i]==p->e[i]);}
  for(unsigned i=0;i<4;i++)h=hashbyte(h,p->env[i]);h=hashbyte(h,p->fenv);h=hashbyte(h,p->mono);for(unsigned i=0;i<4;i++)h=hashbyte(h,p->fx[i]);
  unsigned ids[7]={P_LRATE,P_LWAVE,P_LD_PIT,P_LD_FLT,P_LD_SHP,P_LD_AMP,P_GLIDE};for(unsigned i=0;i<7;i++)h=hashbyte(h,t->p[ids[i]]);
  REQ("decoded preset matches source projection",h==FP_EXPECT[q][2]);REQ("preset keeps pattern",sig==steps_sig(t));checked++;
  // Rotate through >8 cache entries and revisit signed values/program boundaries.
  for(unsigned i=0;i<12;i++)factory_preset(en,(k+i+1)%en->npresets);
  REQ("cache eviction preserves macro",factory_preset(en,k)->e[0]==t->p[P_E0]);
 }
 printf("factory validation: %u projections, %u stars, failures=%u\n",checked,starred,failures);return !!failures;
}
static int audio_cases(void){
 ui_power_on();fm6_init();power_on_parts();song.playing=0;unsigned bad=0;
 for(unsigned j=0;j<NENG_SHOWN;j++){
  unsigned e=ENGINE_ORDER[j];if(e==ENGI_EMPTY||e==ENGI_BREAK)continue;
  for(unsigned pi=0;pi<ENGINES[e]->npresets;pi++){
   track_t *t=&trk[0];set_engine_of(t,e);apply_preset_to(t,pi);t->engine=t->eng_req;memset(t->v,0,sizeof t->v);
   const engine_t *en=ENGINES[e];voice_t *v=&t->v[0];v->active=v->gate=1;v->note=60;v->vel=112;v->env_out=32767;v->env=0x7fffffffu;
   if(en->block)en->block(t);if(en->note_on)en->note_on(t,v);
   vmod_t m={0};m.inc=pitch_inc(60*16);m.pitch16=60*16;m.amp0=m.amp1=24576;m.shape=16384;m.envq15=32767;
   long long energy=0;unsigned peak=0;
   for(unsigned b=0;b<180;b++){int32_t out[CTL]={0};if(en->block)en->block(t);en->render(t,v,out,CTL,&m);for(unsigned k=0;k<CTL;k++){unsigned a=out[k]<0?-(int64_t)out[k]:out[k];energy+=a;if(a>peak)peak=a;}}
   if(!energy||peak>1000000){printf("FAIL engine=%u preset=%u %s energy=%lld peak=%u\n",e,pi,factory_preset(en,pi)->name,energy,peak);bad++;}
   if(e==ENGI_FMINI&&t->p[P_E6]*128+t->p[P_E7]!=(int)pi){printf("FAIL patch slot %u = %d\n",pi,t->p[P_E7]);bad++;}
   if(pi==0)printf("AUDIO %u %s peak=%u energy=%lld\n",e,en->name,peak,energy);
  }
 }
 printf("audio failures=%u\n",bad);return bad?1:0;
}
static void must(int ok,const char *s) { if(!ok){fprintf(stderr,"FAIL %s\n",s);exit(1);} }
static int gated(track_t *t) { int n=0;for(unsigned i=0;i<NVOICE;i++)n+=t->v[i].active&&t->v[i].gate;return n; }
static void frame(void){host_ticks+=16000u;fm1_ms+=16u;ui_input();six_gen_poll();ui_draw();}
static void press(uint32_t label){fm1_in.buttons|=1u<<panel.btn[label];host_pressed|=1u<<panel.btn[label];frame();fm1_in.buttons&=~(1u<<panel.btn[label]);frame();}
static void setup(void) {
 ui_power_on();set_engine_of(&trk[0],ENGI_ANALOG);apply_preset_to(&trk[0],0);trk[0].engine=trk[0].eng_req;fm1_in.keys=fm1_in.notes=kb_prev=0;kb_boot_hold=0;kb_asleep=0;song.grid=0;kb_mask=perf_mask=0;
 for(unsigned i=0;i<NTRK;i++){trk[i].p[P_AHOLD]=trk[i].p[P_AMODE]=trk[i].p[P_CHRD]=trk[i].p[P_SCALE]=0;trk[i].p[P_TRANS]=0;trk[i].p[P_VOICE]=V_POLY;trk[i].p[P_SUS]=127;track_defaults_steps(&trk[i]);}
 song.playing=0;song.octave=0;ui.menu=ui.confirm=ui.layer=0;nm.kind=0;smk_pad_mode=smk_pad_gate=0;fm1_in.frames=400;
}
static void physical(unsigned k,int on,unsigned vel) {
 fm1_in.keys=on?(UINT64_C(1)<<k):0;fm1_in.notes=on&&k>=5&&k<32?1u<<(k-5):0;fm1_in.key_vel[k]=vel;keyboard_block();
}
static int runtime_cases(void) {
 unsigned i;setup();
 for(i=0;i<37;i++) {
  unsigned logical=i<5?27+i:i<32?i-5:i;
  physical(i,1,30+i);must(kb_note[logical]==48+i,"37 keys map C3-C6");must(kb_sn[logical]==1,"single keyboard note");
  int got=0;for(unsigned v=0;v<NVOICE;v++)if(trk[0].v[v].active&&trk[0].v[v].gate&&trk[0].v[v].note==48+i){must(trk[0].v[v].vel==30+i,"key velocity reaches sound engine");got=1;}
  must(got,"key starts real voice");physical(i,0,0);must(!gated(&trk[0]),"key release ends gate");
 }
 physical(36,1,95);song.sel=1;physical(36,0,0);must(!gated(&trk[0])&&!gated(&trk[1]),"outer note release follows original track");
 setup();trk[0].p[P_CHRD]=1;physical(0,1,93);must(kb_sn[27]>1,"outer keys use chord builder");physical(0,0,0);must(!gated(&trk[0]),"outer chord releases all notes");
 setup();trk[0].engine=trk[0].eng_req=ENGI_ANALOG;ui.lane=2;trk[0].p[P_SLEN]=32;ui.bank=1;
 smk_buttons(1u<<SMK_BTN_KNOB_BANK);must(smk_pad_mode&&smk_pad_gate,"pad mode guards held pads");smk_pad_steps();
 for(i=0;i<16;i++) {fm1_in.pad_st[i]=128;smk_pad_steps();must(trk[0].step[16+i].time==ST_NOTE&&trk[0].step[16+i].n,"every pad edits matching step and lane");fm1_in.pad_st[i]=0;smk_pad_steps();}
 must(!fm1_in.notes,"step pads never generate key notes");ui_leds();smk_pad_picture();
 for(i=0;i<16;i++)must(host_pad_rgb[i][0]&&host_pad_rgb[i][0]==host_pad_rgb[i][1]&&host_pad_rgb[i][1]==host_pad_rgb[i][2],"matching white step LEDs");
 fm1_in.pad_st[11]=128;smk_pad_steps();must(trk[0].step[27].time==ST_REST,"pad 12 toggles step 28 off");
 smk_buttons(1u<<SMK_BTN_KNOB_BANK);smk_pad_steps();must(smk_pad_gate&&smk_pad_separate,"switching to play waits for release");fm1_in.pad_st[11]=0;smk_pad_steps();must(!smk_pad_gate&&!smk_pad_separate,"play reopens after release");
 setup();smk_fbank=0;memset(&smk_fader_state,0,sizeof smk_fader_state);for(i=0;i<4;i++){fm1_in.fader[i]=0;trk[i].p[P_LEVEL]=100;}
 smk_faders_poll();for(i=0;i<4;i++)must(trk[i].p[P_LEVEL]==100,"no fader jump on load");
 for(i=0;i<4;i++)fm1_in.fader[i]=110;smk_faders_poll();for(i=0;i<4;i++)must(trk[i].p[P_LEVEL]==110,"four faders select tracks 1-4");
 song.sel=4;trk[4].p[P_LEVEL]=90;trk[5].p[P_LEVEL]=95;smk_faders_poll();must(trk[4].p[P_LEVEL]==90&&trk[5].p[P_LEVEL]==95,"track 5-6 window rearms pickup");
 fm1_in.fader[0]=80;fm1_in.fader[1]=80;smk_faders_poll();must(trk[4].p[P_LEVEL]==80&&trk[5].p[P_LEVEL]==80&&trk[0].p[P_LEVEL]==110,"upper track window isolated");
 ui.menu=1;unsigned bank=smk_fbank;smk_buttons(1u<<SMK_BTN_FADER_BANK);must(smk_fbank==bank,"modal menu retains controls");

 setup();smk_midi_init();usb.config=0;mo_lvl=MO_KEYS;
 uint32_t usb_w=mo_w;physical(7,1,100);must(smk_midi.w==1&&mo_w==usb_w,"TRS key output works without USB");
 for(i=0;i<8;i++)smk_midi_out_poll();must(smk_midi.sent==3,"TRS note-on drains without USB");
 song.sel=1;physical(7,0,0);for(i=0;i<8;i++)smk_midi_out_poll();must(smk_midi.sent==6,"TRS note-off follows original owner across track change");
 usb.config=1;uint16_t trs_w=smk_midi.w;midi_out_event(0x90u<<8|65u<<16|100u<<24|9u);must(mo_w==usb_w+1u&&smk_midi.w==trs_w+1u,"USB and TRS receive the same note independently");usb.config=0;
 mo_lvl=MO_OFF;mo_last=MO_KEYS;mo_block(CTL);must(smk_midi.muted&&smk_midi.reset,"existing MIDI OUT OFF resets TRS safely");
 smk_midi_init();mo_lvl=MO_KEYS;song.sel=0;smk_bend14=1234;smk_modw=72;smk_wheels_block();
 uint16_t wheel_w=smk_midi.w;must(wheel_w==2,"wheel bend and modulation reach TRS");
 song.sel=1;smk_wheels_block();must(smk_midi.w==wheel_w+4,"track change resets old MIDI channel and sends current wheels");
 must((smk_midi.queue[wheel_w&63]&0xFFFFFF00u)==(0xE0u<<8|64u<<24),"old channel pitch bend centered");
 must((smk_midi.queue[(wheel_w+1)&63]&0xFFFFFF00u)==(0xB0u<<8|1u<<16),"old channel modulation reset");
 wheel_w=smk_midi.w;mo_lvl=MO_OFF;smk_bend14=2345;smk_modw=83;smk_wheels_block();must(smk_midi.w==wheel_w,"MIDI OFF suppresses wheel transmission");
 mo_lvl=MO_KEYS;smk_midi.generation++;smk_wheels_block();must(smk_midi.w==wheel_w+2,"panic completion refreshes wheel values once");
 wheel_w=smk_midi.w;smk_wheels_block();must(smk_midi.w==wheel_w,"unchanged wheels do not flood MIDI");
 setup();press(B_PLAY);must(transport_req==1,"physical SEQ PLAY starts transport");
 transport_req=0;song.playing=1;press(B_PLAY);must(transport_req==2,"physical SEQ PLAY stops running transport");
 setup();press(B_REC);must(transport_req==1,"physical SEQ REC starts live recording");transport_req=0;song.playing=1;press(B_PLAY);must(transport_req==2,"PLAY stops REC-started transport");
 setup();ui.menu=1;song.playing=1;press(B_PLAY);must(transport_req==2,"PLAY stops while menu is open");
 puts("SMK_RUNTIME_PASS: 37 real key voices/velocity/release, chord and track ownership, 16 step pads/LEDs, held-mode guard, faders and modal controls");return 0;
}

#include "smk_audit_cases.h"
int main(int argc,char **argv){int bad=expansion_cases(argc,argv);bad+=factory_cases();bad+=audio_cases();bad+=runtime_cases();smk_audit_cases();printf("JAZZY_SMK_FULL failures=%d\n",bad);return !!bad;}
