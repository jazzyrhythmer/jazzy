"""Author the original JAZZY world sprites on a 32 x 28 pixel grid."""
from pathlib import Path
from PIL import Image, ImageDraw

# 0 transparent, 1 ink, 2/3 main light/shade, 4/5 second light/shade,
# 6 highlight, 7/8 skin light/shade, 9 dark panel, 10 reflected light.
W, H = 32, 28
sprites = {}
def sprite(name):
    global canvas, d
    canvas = Image.new('L', (W,H), 0)
    sprites[name] = canvas
    d = ImageDraw.Draw(canvas)
def rect(x,y,w,h,c):
    if w <= 0 or h <= 0: return
    d.rectangle((x,y,x+w-1,y+h-1),fill=c)
def poly(points,c,edge=1):
    d.polygon(points,fill=c,outline=edge)
def oval(x,y,w,h,c):
    d.ellipse((x,y,x+w-1,y+h-1),fill=c,outline=1)
def roundbox(x,y,w,h,c,shade=0):
    poly([(x+3,y),(x+w-4,y),(x+w-1,y+3),(x+w-1,y+h-4),
          (x+w-4,y+h-1),(x+3,y+h-1),(x,y+h-4),(x,y+3)],c)
    if shade:
        rect(x+3,y+h-4,w-6,2,shade)
        rect(x+4,y+2,w-8,1,6)
def eye(x,y):
    rect(x,y,4,5,6); rect(x+2,y+1,2,3,1)
def front_eyes(x,y,gap):
    for left in (x,x+gap):
        rect(left,y,3,4,6)
        rect(left+1,y+1,2,2,1)
def bolt(x,y):
    rect(x,y,2,2,10)
def shoe(x,y,c):
    poly([(x+1,y),(x+5,y),(x+5,y+2),(x+7,y+3),(x+7,y+4),(x,y+4),(x,y+2)],c)
    rect(x+2,y+1,3,1,6)

# People use individual poses. Their face, fingers and clothing share ink weights.
for i in range(3):
    sprite('athlete'+str(i))
    kick=[0,-2,2][i]; guard=[0,2,-2][i]
    poly([(11,18),(17,18),(22+kick,24),(19+kick,26),(15,23),(12-kick,26),(7-kick,26)],3)
    shoe(5-kick,22,2); shoe(18+kick,22,4)
    roundbox(10,11,13,11,2,3)
    rect(12,18,8,2,5); rect(14,18,3,2,6)
    oval(6,13+guard,8,8,4); oval(20+i*2,13-guard,9,8,4)
    rect(22+i*2,14-guard,3,1,6)
    roundbox(8,2,18,15,2,3)
    poly([(11,7),(24,7),(24,12),(21,15),(13,15),(11,12)],7)
    rect(12,11,2,2,8); eye(19,8); rect(17,14,5,1,8)
    rect(13,4,8,2,6)
for i in range(2):
    sprite('skater'+str(i))
    poly([(7,20),(14,17),(20,18),(24,22),(21,24),(17,21),(13,22),(8,25)],3)
    shoe(6,21,4); shoe(19,21,4)
    poly([(9,13),(20,12),(22,17),(18,21),(9,18)],4)
    oval(5-i*3,12-i*2,8,6,7); oval(20+i,12-i*3,7,6,7)
    roundbox(11,3-i,17,14,2,3)
    poly([(14,8-i),(27,8-i),(26,13-i),(23,15-i),(15,14-i)],7)
    eye(22,9-i); rect(14,5-i,8,1,6)

sprite('dog')
poly([(4,17),(1,13),(1,9),(4,11),(6,15),(9,14),(11,19),(7,21)],3)
roundbox(4,14,22,11,2,3)
roundbox(4,21,7,6,3); roundbox(18,21,7,6,3)
roundbox(17,5,13,16,2,3)
poly([(17,8),(23,7),(23,19),(19,22),(16,17)],3)
roundbox(23,12,9,8,7,8); rect(29,12,2,2,1); eye(24,8)
rect(8,16,8,2,6); rect(21,18,4,2,4)

sprite('cat')
poly([(8,21),(3,20),(1,15),(2,9),(6,8),(7,11),(4,13),(5,17),(10,17)],3)
oval(4,14,23,13,2); roundbox(9,21,14,6,3)
poly([(10,7),(11,2),(17,6),(22,6),(27,2),(29,10),(29,17),(24,21),(15,21),(9,16)],2)
poly([(12,4),(16,7),(12,9)],4); poly([(26,4),(26,9),(22,7)],4)
oval(15,12,13,8,7); eye(15,9); eye(23,9); rect(20,14,3,2,1)
rect(22,18,3,1,8); rect(28,14,3,1,6); rect(11,15,4,1,6)

sprite('moose')
oval(4,15,22,12,3); roundbox(7,20,6,7,2); roundbox(17,21,7,6,2)
poly([(15,10),(10,9),(5,4),(7,1),(9,2),(8,5),(11,7),(11,4),(14,4),(14,8),(18,10)],7)
poly([(20,10),(24,8),(24,3),(27,3),(27,6),(29,4),(28,1),(31,1),(31,6),(27,11),(21,13)],7)
roundbox(13,8,16,15,2,3)
roundbox(19,14,12,8,7,8); eye(20,11); rect(26,17,2,2,1)

for down in range(2):
    sprite('bird'+str(down))
    poly([(11,16),(2,12),(5,19),(11,20)],3)
    oval(7,10,20,14,2)
    oval(15,16,11,8,7)
    oval(18,7,10,12,2)
    poly([(26,11),(31,13),(26,15)],4)
    eye(23,9)
    if down:
        poly([(12,14),(20,15),(15,25),(10,27),(11,20)],3)
        rect(13,18,5,2,10)
    else:
        poly([(13,16),(7,8),(8,1),(13,5),(18,10),(20,16)],3)
        rect(10,6,4,2,10)
    rect(19,9,3,1,6)

sprite('cow')
roundbox(3,12,24,13,6,10); roundbox(5,21,6,6,9); roundbox(19,21,6,6,9)
poly([(13,13),(17,13),(19,16),(17,20),(12,20),(11,16)],9)
poly([(18,7),(17,3),(21,5),(22,8)],7); poly([(27,8),(28,4),(31,3),(30,8)],7)
roundbox(17,6,14,15,6,10); roundbox(19,13,12,8,4,5)
front_eyes(20,9,6); rect(22,16,2,2,1); rect(27,16,2,2,1)
rect(22,7,5,1,10); rect(24,15,3,1,6)
rect(16,17,3,3,4); bolt(16,20)
poly([(4,15),(1,11),(1,8),(3,10),(5,12)],9)

sprite('snail')
roundbox(2,19,28,8,2,3); oval(4,6,20,19,4); oval(7,9,14,13,7)
poly([(10,10),(17,10),(19,13),(18,17),(14,19),(11,17),(11,14),(15,13),(16,15),(14,16),(15,17),(18,15),(17,12),(11,12)],5,None)
oval(21,14,10,11,2); rect(22,10,2,6,3); rect(27,9,2,6,3); eye(26,15)
rect(22,23,5,1,6)

sprite('giraffe')
roundbox(3,15,21,11,7,8); roundbox(5,22,5,6,8); roundbox(16,22,5,6,8)
roundbox(16,5,9,17,7,8)
roundbox(17,3,14,11,7,8)
rect(20,0,2,5,1); rect(26,0,2,5,1); rect(20,0,2,1,4); rect(26,0,2,1,4)
eye(25,5); rect(29,10,2,2,1)
for x,y in [(7,17),(13,19),(18,15),(19,10)]: rect(x,y,3,3,4)

sprite('peacock')
for x,y in [(2,7),(7,3),(13,1),(19,3),(24,7)]:
    oval(x,y,8,16,2)
    oval(x+2,y+2,4,6,4)
    rect(x+3,y+3,2,2,6)
oval(9,14,14,12,3)
oval(16,10,10,12,2); eye(21,12)
poly([(24,14),(31,17),(25,19)],7)
rect(14,24,2,3,7);rect(19,24,2,3,7)

sprite('dryer')
roundbox(1,7,22,12,2,3)
roundbox(18,9,13,8,9,3)
rect(23,11,6,3,10)
poly([(6,17),(15,17),(13,25),(10,27),(7,25)],2)
rect(8,19,3,3,4); rect(4,11,4,4,3); bolt(10,11)

sprite('rocket')
poly([(12,15),(18,15),(24,22),(24,26),(18,23),(12,23),(6,26),(6,22)],4)
poly([(15,1),(20,7),(21,13),(19,23),(11,23),(9,13),(10,7)],6)
poly([(15,1),(19,5),(20,8),(10,8),(11,5)],4)
oval(11,9,9,9,9); oval(13,11,5,5,10); bolt(13,11)
rect(12,20,6,3,3); rect(12,24,6,2,1)

sprite('cockpit')
poly([(5,4),(26,4),(30,17),(28,24),(3,24),(1,17)],3)
poly([(7,6),(24,6),(27,15),(4,15)],9)
rect(5,17,22,3,2);rect(5,21,22,2,10)
for x in range(7,27,5):
    rect(x,18,2,1,4)

sprite('wizard')
shoe(5,22,3); shoe(16,22,3)
poly([(8,15),(20,15),(25,23),(22,26),(5,26),(4,22)],3)
poly([(10,16),(18,16),(20,24),(8,24)],2)
rect(9,22,10,2,4); bolt(13,20)
roundbox(7,8,16,13,7,8)
front_eyes(9,13,7); rect(13,18,4,1,8)
poly([(2,11),(7,9),(11,4),(18,1),(23,2),(19,5),(21,9),(27,11),(26,13),(3,13)],2)
rect(6,10,17,2,4); rect(12,6,6,1,6)

sprite('press')
roundbox(2,3,28,24,3,9)
rect(6,8,20,13,1); rect(7,9,18,11,9)
rect(12,6,8,2,2); rect(5,23,22,2,2)
bolt(4,5);bolt(26,5); bolt(5,22);bolt(25,22)

sprite('plane')
poly([(2,8),(30,11),(11,23),(9,17),(3,16)],6)
poly([(9,17),(30,11),(15,22),(11,26)],10)
poly([(7,14),(30,11),(13,18),(10,22)],3)
rect(5,11,6,1,6)

sprite('coaster')
poly([(17,13),(20,9),(26,9),(28,14),(24,17)],2)
roundbox(18,4,10,9,7,8)
poly([(17,7),(18,3),(23,2),(27,3),(28,6),(30,6),(30,8),(18,8)],2)
rect(22,4,4,1,6); rect(25,8,2,2,1)
poly([(1,13),(5,11),(12,13),(18,13),(20,9),(28,9),(31,14),(29,22),(3,22),(0,18)],4)
rect(5,15,22,3,5); rect(7,13,11,1,6)
oval(4,20,7,7,9); oval(22,20,7,7,9); bolt(6,22);bolt(24,22)

sprite('clock')
roundbox(4,4,24,24,3,9)
oval(7,7,18,18,6); oval(9,9,14,14,10)
for x,y in [(15,8),(15,22),(8,15),(22,15)]:rect(x,y,2,2,1)
rect(12,2,8,3,4)



sprite('fire')
poly([(3,22),(6,21),(16,24),(25,20),(29,22),(28,26),(6,27),(3,25)],5)
poly([(8,23),(5,17),(8,12),(11,16),(10,11),(16,5),(16,1),(21,7),(22,12),(25,9),(27,16),(25,21),(21,24)],4)
poly([(10,21),(8,18),(12,16),(14,18),(15,12),(19,8),(20,15),(23,17),(22,22),(20,24)],7)
poly([(13,22),(17,16),(20,18),(19,23)],6)
rect(5,23,4,2,7); rect(25,22,3,2,7); rect(10,25,11,1,8)

sprite('wreck')
oval(3,2,26,26,4)
oval(7,5,17,17,5); rect(8,7,9,2,6)
rect(7,11,2,4,6); rect(18,19,7,2,3)

sprite('vacuum')
roundbox(1,10,29,14,4,5)
roundbox(7,6,15,10,2,3)
oval(3,19,10,9,9); oval(20,19,9,9,9)
bolt(7,22); bolt(23,22)
rect(12,11,6,3,10); rect(25,14,4,3,3)

sprite('deck')
roundbox(0,3,32,23,3,9)
oval(2,5,20,19,9); oval(4,7,16,15,1)
oval(6,9,12,11,9); oval(8,10,8,9,1); oval(9,11,6,7,4)
rect(11,13,2,3,6)
roundbox(23,5,7,6,2,3); rect(25,7,2,2,6)
for x in (19,22,25,28): rect(x,22,2,2,10)

sprite('bike')
oval(0,13,15,15,9); oval(17,13,15,15,9)
oval(3,16,9,9,10); oval(20,16,9,9,10)
oval(5,18,5,5,9); oval(22,18,5,5,9)
poly([(5,19),(9,12),(13,10),(17,10),(20,13),(23,13),(25,19),(19,22),(11,21)],4)
rect(8,10,8,2,9); rect(12,15,7,4,3); rect(12,17,5,1,6)
poly([(20,10),(25,11),(27,15),(24,16)],2)
rect(25,12,3,2,6); rect(4,13,3,2,5); bolt(6,20); bolt(24,20)

sprite('racer')
poly([(0,13),(4,13),(9,11),(13,7),(20,7),(25,11),(30,13),(31,16),(31,21),(28,23),(3,23),(0,20)],4)
poly([(10,12),(14,8),(19,8),(23,12)],10)
rect(17,8,1,4,1); rect(1,9,7,2,5); rect(3,11,2,3,1)
rect(6,14,19,1,6); rect(11,18,11,3,5)
rect(27,14,4,2,6); rect(28,19,4,2,9); rect(1,14,4,2,2)
oval(1,15,13,13,9); oval(18,15,13,13,9)
oval(4,18,7,7,10); oval(21,18,7,7,10)
bolt(6,20); bolt(23,20)

sprite('screen')
roundbox(1,3,30,22,3,9)
roundbox(4,6,24,14,9)
rect(5,6,22,1,10)
rect(6,22,7,1,6); rect(21,22,5,1,4)

# Costume variants retain the original articulation and redraw the silhouette and gear.
for i in range(3):
    sprite('fencer'+str(i))
    canvas.paste(sprites['athlete'+str(i)])
    roundbox(7,2,20,16,6,10)
    roundbox(11,6,15,10,9)
    for y in (8,10,12):
        rect(13,y,11,1,10)
    rect(11,15,14,2,3)
    rect(12,18,9,2,6)
    rect(22+i*2,15-[0,2,-2][i],4,3,6)

for i,(hx,hy) in enumerate(((23,16),(24,9),(27,17))):
    sprite('sword'+str(i))
    shoe(6-i,22,3); shoe(18+i,22,3)
    poly([(8,17),(20,16),(25,23),(18,24),(14,21),(8,24),(5,22)],3)
    roundbox(8,13,14,10,2,3)
    rect(10,19,10,2,4); bolt(13,19)
    poly([(17,15),(hx-2,hy-2),(hx+1,hy),(hx,hy+2),(18,19)],2)
    oval(hx-2,hy-2,5,5,7)
    roundbox(7,3,17,14,7,8)
    poly([(7,10),(8,5),(12,2),(19,2),(23,4),(24,9),(21,7),(11,7)],5)
    rect(9,7,13,2,4); rect(12,4,7,1,6)
    front_eyes(10,9,7); rect(13,14,5,1,8)

# Three support poses share the exact same boots. The renderer supplies the
# wrists and elbows, so hands remain on the moving bar between key poses.
for i,top in enumerate((8,5,2)):
    sprite('lifter'+str(i))
    hip = 22-i*2
    poly([(11,hip),(20,hip),(24,24),(21,26),(17,23),(14,23),(10,26),(7,24)],3)
    shoe(5,22,3); shoe(20,22,3)
    roundbox(8,top+10,17,hip-top-8,4,5)
    rect(11,hip-2,11,2,9); rect(15,hip-2,3,2,6)
    roundbox(8,top,17,13,7,8)
    front_eyes(11,top+6,7); rect(14,top+11,5,1,8)

sprite('dog_step')
canvas.paste(sprites['dog'])
rect(4,21,7,7,0);rect(18,21,7,7,0)
poly([(4,20),(9,21),(10,23),(7,27),(3,27),(5,24)],3)
poly([(18,20),(24,20),(26,25),(26,26),(21,26),(20,23)],3)
rect(4,25,3,1,6);rect(23,24,2,1,6)
poly([(17,8),(22,7),(24,15),(20,18),(17,17),(16,12)],3)

sprite('cat_step')
canvas.paste(sprites['cat'])
rect(0,5,8,14,0)
poly([(8,23),(3,20),(1,16),(1,11),(4,7),(6,8),(6,11),(4,14),(5,17),(9,18)],3)
rect(16,8,2,1,1); rect(24,8,2,1,1)

# A side-on paw with a wrist, two scalloped toes and visible pads.
sprite('paw')
poly([(12,18),(14,16),(17,16),(18,17),(20,17),(22,19),(22,21),
      (21,22),(22,23),(21,25),(16,25),(14,24),(12,23),(11,21)],2)
rect(16,18,4,6,7); rect(19,19,2,2,8); rect(19,23,2,1,8)
rect(15,19,2,1,6)

# Each backdrop is drawn on a two-pixel grid. A mark can respond to the
# sequencer or drift in the wind while the fixed scenery stays in place.
def R(x,y,w,h,light=False,beat=False,wind=False):
    return x//2+(128 if light else 0), y//2+(64 if beat else 0), w//2+(128 if wind else 0), h//2
def L(x,y,a,b,light=False,beat=False,wind=False):
    return x//2+(128 if light else 0), y//2+128+(64 if beat else 0), a//2+(128 if wind else 0), b//2

backdrops = {
    'dog': [  # Park path, a bench and a tree
        R(22,46,24,18),R(28,38,12,12),R(32,62,4,28),
        R(166,67,38,6,True),R(168,74,34,4),R(172,78,4,12),R(196,78,4,12),
        L(15,96,224,96)],
    'cat': [  # Windows and curtain
        R(26,26,32,32),R(30,30,24,24,False,True),R(40,30,2,24,True),
        L(30,42,54,42,True),R(182,22,28,40),R(204,20,6,50,True,False,True)],
    'dryer': [  # Laundry room, mirror and wall tiles
        R(30,22,42,52),R(34,26,34,44),L(36,58,62,32,True),
        L(114,56,218,56),L(174,32,174,86),L(114,80,218,80)],
    'boxer': [  # Ring ropes and corner post
        R(24,36,6,52),R(210,36,6,52),L(28,44,210,44),
        L(28,58,210,58),L(28,72,210,72),R(26,34,8,14,False,True)],
    'fire': [  # Campsite, fir trees and a night sky
        L(20,86,40,44),L(40,44,58,86),L(30,66,50,66),
        L(180,86,202,40),L(202,40,220,86),L(190,64,212,64),
        R(70,28,4,4,False,True),R(164,20,4,4,True)],
    'rocket': [  # Launch tower and stars
        R(36,34,4,62),R(54,34,4,62),R(36,34,22,4),L(38,44,56,64),
        L(56,64,38,84),R(190,24,4,4,False,True),R(168,46,2,2,True),L(18,96,222,96)],
    'cockpit': [  # A pair of radar satellites
        R(20,42,14,10),R(22,37,10,4,True),L(26,52,18,66),
        R(208,30,12,12),L(214,42,222,54),R(204,25,20,4,False,True)],
    'moose': [  # Distant ridge and pine trees
        L(16,69,46,38),L(46,38,82,70),L(142,68,172,38),
        L(172,38,220,69),R(34,76,4,20),R(195,70,4,26),L(18,96,222,96)],
    'bird': [  # Windblown clouds and treetops
        R(26,24,30,4,False,False,True),R(34,20,14,4,True,False,True),
        R(166,38,38,4,False,True,True),R(174,34,16,4,True,False,True),
        L(16,100,46,78),L(46,78,76,100),L(162,100,196,80),L(196,80,224,100)],
    'skater': [  # Two different ramps
        L(18,86,60,58,True),R(18,86,44,6),L(60,58,82,58),
        L(158,78,182,62,True),L(182,62,218,86),R(172,88,44,4,False,True)],
    'wizard': [  # Stone arch, runes and candles
        R(36,40,8,52),R(194,40,8,52),L(42,40,78,20),
        L(160,20,196,40),R(64,60,6,12,False,True),R(172,66,6,12,False,True)],
    'cow': [  # Barn roof, stall door, fence and grass
        R(24,56,46,26),L(18,57,47,37,True),L(47,37,78,57,True),
        R(42,66,14,16,True),L(42,66,54,80),L(82,78,222,78),
        L(88,86,220,86),R(90,74,4,20,True),R(168,74,4,20,True),
        R(218,74,4,20,True),R(16,96,208,8),
        L(26,99,20,91,True,False,True),L(64,101,68,91,True,False,True),
        L(174,103,166,95,True,False,True),L(212,101,218,93,True,False,True)],
    'fence': [  # Indoor fencing piste and scoring lights at the sides
        R(28,27,16,4,True,True),R(194,27,16,4,False,True),
        L(18,98,222,98),R(24,92,10,4),R(208,92,10,4)],
    'press': [  # Workshop shelf, stacked material and switch
        R(20,74,50,4),R(26,60,32,12),R(30,62,24,4,True),
        R(174,32,40,4),R(190,38,18,30),R(194,42,8,6,False,True)],
    'plane': [  # Layered clouds across an open sky
        R(18,22,38,4,True,False,True),R(28,18,16,4,False,True,True),
        R(154,48,58,6,False,False,True),R(166,42,22,6,True,False,True),
        R(38,92,48,4),R(46,88,30,4)],
    'coaster': [  # Small city behind the loop and a station light
        R(22,52,22,20),R(50,42,14,30),R(166,48,18,24),
        R(192,36,24,36),R(200,44,6,6,False,True),L(14,72,226,72)],
    'snail': [  # Garden border and upright leaves
        L(18,98,224,98),R(30,66,4,30),L(32,74,20,64),L(32,84,48,68),
        R(190,68,4,28),L(192,82,206,62),R(68,86,10,8,False,True)],
    'clocks': [  # Clockmaker's shelf and tick marks
        R(22,94,198,4),R(22,98,4,8),R(214,98,4,8),
        R(44,24,8,4,True,True),R(112,24,8,4,False,True),R(180,24,8,4,True,True)],
    'ball': [  # Construction site and a striped barricade
        R(18,76,4,24),R(52,76,4,24),L(20,84,52,84,True),
        L(24,84,32,77,False,True),L(38,84,46,77,False,True),R(196,37,28,44)],
    'vacuum': [  # A room with a low cabinet and a patterned rug
        L(20,83,222,83),R(150,42,58,31),R(154,46,50,9,True),
        R(176,49,8,2,False,True),L(34,99,208,99),L(44,104,194,104)],
    'fan': [  # Aviary, perches and branches
        L(26,41,66,65),L(34,50,60,46),L(176,62,218,36),
        L(188,54,214,58),R(30,38,6,6,False,False,True),R(208,40,6,6,False,True,True)],
    'sword': [  # Dojo posts and hanging pennants
        R(32,26,4,68),R(82,26,4,46),R(154,26,4,46),R(204,26,4,68),
        L(24,26,216,26),R(60,31,10,12,False,True),R(170,31,10,12,True,True)],
    'vinyl': [  # Two studio speakers with bouncing meter marks
        R(16,40,26,48),R(198,40,26,48),R(22,50,14,8,True),
        R(204,50,14,8,True),R(22,68,14,12,False,True),R(204,68,14,12,False,True)],
    'lifter': [  # Rack and stored plates to both sides of the platform
        R(16,56,42,4),R(182,56,42,4),R(22,48,6,8,True),
        R(32,42,6,14),R(42,36,6,20,True),R(190,40,6,16,True),R(202,46,6,10),
        R(110,18,20,4,False,True)],
    'rider': [  # Guardrails and street lights
        L(18,78,220,78),R(22,76,4,22),R(204,76,4,22),
        R(54,32,4,40),R(56,32,16,4,True,True),R(178,44,4,28),R(182,44,14,4,False,True)],
    'giraffe': [  # Savanna sun and a broad acacia canopy
        R(32,24,18,14,True),L(16,86,222,86),R(192,58,4,38),
        R(166,52,48,8),R(176,46,32,6,True),L(195,68,212,54)],
    'racer': [  # Track barrier and race lights
        L(16,82,224,82),R(20,75,42,4),R(88,75,48,4),R(170,75,52,4),
        R(166,30,4,44),R(168,30,30,6),R(173,31,4,4,True,True),R(187,31,4,4,False,True)],
    'spar': [  # Open-air fencing lane with light posts at the edges
        R(20,52,4,42),R(216,52,4,42),R(18,48,10,6,False,True),R(212,48,10,6,True,True),
        L(18,97,224,97)],
    'gust': [  # Hilltop wind vane and moving cloud
        L(16,88,62,68),L(62,68,118,88),R(184,55,4,34),
        L(168,56,202,56,False,True,True),R(132,30,40,4,False,False,True)],
    'wiper': [  # Garage frame with rain above the windscreen
        R(24,37,8,56),R(208,37,8,56),L(26,36,214,36),
        L(62,19,56,27,True,False,True),L(110,22,104,30,False,True,True),
        L(166,18,160,26,True,False,True)],
    'smile': [  # Flecks in the liquid outside the resonance rings
        R(30,30,4,4,True,False,True),R(196,32,4,4,False,True,True),
        R(47,81,3,3,False,False,True),R(202,84,4,4,True,False,True)],
}

# Rows are exactly 32 pixels. Each byte packs a palette index and a length of 1–16.
data, offsets = [], []
for image in sprites.values():
    offsets.append(len(data))
    for y in range(H):
        x = 0
        while x < W:
            color = image.getpixel((x, y))
            end = x + 1
            while end < min(W, x + 16) and image.getpixel((end, y)) == color:
                end += 1
            data.append((color << 4) | (end - x - 1))
            x = end
target = Path(__file__).resolve().parents[2] / 'rhythmer/firmware/src/jazzy_world_sprites.h'
with target.open('w') as f:
    f.write('/* Generated from tools/jazzy/draw_world_sprites.py. Original JAZZY pixel art. */\n')
    f.write('enum { ' + ', '.join('JS_' + name.upper() for name in sprites) + ' };\n')
    f.write('static const uint16_t JS_START[] = {' + ', '.join(map(str, offsets)) + '};\n')
    f.write('static const uint8_t JS_RUNS[] = {\n')
    for i in range(0, len(data), 16):
        f.write(' ' + ','.join(map(str, data[i:i+16])) + ',\n')
    f.write('};\n')
    f.write('static const uint8_t JS_BG_INDEX[][2] = {\n')
    start=0
    for name,marks in backdrops.items():
        f.write(f' [JW_{name.upper()}] = {{{start},{len(marks)}}},\n')
        start+=len(marks)
    assert start<=256
    f.write('};\nstatic const uint8_t JS_BG_MARKS[][4] = {\n')
    for name,marks in backdrops.items():
        f.write(f' /* {name} */\n')
        for mark in marks:
            f.write(' {'+','.join(map(str,mark))+'},\n')
    f.write('};\n')
print(len(sprites), 'sprites,', len(data) + len(offsets) * 2, 'bytes')
