/* SPDX-License-Identifier: GPL-3.0-only
 * SMK-37 storage integration by Jazzy Rhythmer.
 * Shared-sector copy-on-write store: retain every current object, write its
 * replacement into a different sector, verify it, and reclaim only old copies.
 * This preserves all 23 logical IDs and their original 3840-byte wire formats
 * inside the 27 store sectors left after the owner/bank/staging reservations. */
#pragma once
#define SMK_STORE_OWNER 0xAF000u
#define SMK_BANK_HOME   0xB0000u
#define SMK_BANK_STAGE  0xB1000u
#define SMK_STORE_NONE  0xFFFFFFFFu
_Static_assert(OBJ_COUNT + 1u <= (FL_DATA_HI - FL_DATA_LO) / ST_SECTOR - 3u,
               "SMK store needs room for every logical object plus a COW spare");

static int smk_store_sector(uint32_t p)
{
    return p >= FL_DATA_LO && p < FL_DATA_HI && !(p & (ST_SECTOR - 1u)) &&
           p != SMK_STORE_OWNER && p != SMK_BANK_HOME && p != SMK_BANK_STAGE;
}
static int smk_store_header(uint32_t p, st_hdr_t *h)
{
    return !smk_store_sector(p) || st_read(p, h, sizeof *h) || h->magic != ST_MAGIC ||
           h->type >= OBJ_COUNT || h->slot > 1u || h->len > ST_PAYLOAD_MAX ||
           h->hcrc != st_crc32(h, sizeof *h - 4u);
}
static uint32_t smk_store_find(uint32_t obj, uint32_t copy)
{
    uint32_t p, best = SMK_STORE_NONE, seq = 0;
    st_hdr_t h;
    for (p = FL_DATA_LO; p < FL_DATA_HI; p += ST_SECTOR) {
        if (smk_store_header(p, &h) || h.type != obj || h.slot != copy)
            continue;
        if (best == SMK_STORE_NONE || (h.seq != seq && h.seq - seq < 0x80000000u)) {
            best = p;
            seq = h.seq;
        }
    }
    return best;
}
static int st_current(uint32_t obj, st_hdr_t *h);
static uint32_t smk_store_allocate(void)
{
    uint32_t keep[OBJ_COUNT], obj, n;
    static uint8_t cursor;
    st_hdr_t h;
    /* st_current checks the payload too: never reclaim the fallback of a
     * corrupt or interrupted newer write. Scratch contents are not retained. */
    for (obj = 0; obj < OBJ_COUNT; obj++) {
        int c = st_current(obj, &h);
        keep[obj] = c < 0 ? SMK_STORE_NONE : smk_store_find(obj, (uint32_t)c);
    }
    for (n = 0; n < 30u; n++) {
        uint32_t i = (cursor + n) % 30u, p = FL_DATA_LO + i * ST_SECTOR;
        if (!smk_store_sector(p))
            continue;
        for (obj = 0; obj < OBJ_COUNT && keep[obj] != p; obj++) {}
        if (obj == OBJ_COUNT) {
            cursor = (uint8_t)((i + 1u) % 30u);
            return p;
        }
    }
    return SMK_STORE_NONE;
}
static int smk_store_owner(void)
{
    static const uint8_t tag[16] = "SMK37DATAJAZZY01";
    uint8_t got[16];
    uint32_t p;
    if (!st_read(SMK_STORE_OWNER, got, sizeof got) && !memcmp(got, tag, sizeof got))
        return 0;
    /* Invalidate ownership first and commit it last. On a cut, the next boot
     * repeats the clear; factory calibration and uploaded A/B loops stay intact. */
    if (st_erase(SMK_STORE_OWNER))
        return -1;
    for (p = FL_DATA_LO; p < FL_DATA_HI; p += ST_SECTOR)
        if (p != SMK_STORE_OWNER && st_erase(p))
            return -1;
    if (st_prog(SMK_STORE_OWNER, tag, sizeof tag) || st_read(SMK_STORE_OWNER, got, sizeof got))
        return -1;
    return memcmp(got, tag, sizeof got) ? -1 : 0;
}
