/* SPDX-License-Identifier: GPL-3.0-only
 * JAZZY: Painted Worlds. Original pixel sprites; UI thread only.
 * Art uses palette-indexed row runs. No framebuffers or per-frame allocations.
 */
enum {JW_DOG,JW_CAT,JW_DRYER,JW_BOXER,JW_FIRE,JW_ROCKET,JW_COCKPIT,JW_MOOSE,
 JW_BIRD,JW_SKATER,JW_WIZARD,JW_COW,JW_FENCE,JW_PRESS,JW_PLANE,JW_COASTER,
 JW_SNAIL,JW_CLOCKS,JW_BALL,JW_VACUUM,JW_FAN,JW_SWORD,JW_VINYL,JW_LIFTER,JW_RIDER,JW_GIRAFFE,JW_RACER,JW_SPAR,JW_GUST,JW_WIPER,JW_SMILE};
#include "jazzy_world_sprites.h"
static unsigned jazzy_object(unsigned e){
 static const uint8_t kind[NENGINES]={
  [ENGI_WAVETABLE]=JW_DOG,[ENGI_PHASE]=JW_CAT,[ENGI_LOFI]=JW_DRYER,[ENGI_M2STAT]=JW_BOXER,
  [ENGI_M2SAW]=JW_RIDER,[ENGI_M2SID]=JW_ROCKET,[ENGI_ANALOG]=JW_RACER,[ENGI_FM6]=JW_COCKPIT,
  [ENGI_WHEEL]=JW_MOOSE,[ENGI_MELO_TRIO]=JW_BIRD,[ENGI_FMINI]=JW_SKATER,
  [ENGI_OBER]=JW_WIZARD,[ENGI_JUNO]=JW_COW,[ENGI_CS]=JW_FENCE,[ENGI_KW_ANALOG]=JW_PRESS,
  [ENGI_KW_CS]=JW_PLANE,[ENGI_KW_WAVE]=JW_COASTER,[ENGI_KW_FM]=JW_SPAR,
  [ENGI_KW_PHASE]=JW_SNAIL,[ENGI_KW_SYNC]=JW_CLOCKS,[ENGI_KW_KICK]=JW_FIRE,[ENGI_LXR]=JW_BALL,
  [ENGI_KW_GROWL]=JW_VACUUM,[ENGI_KW_ADD]=JW_FAN,[ENGI_HORT]=JW_SWORD,
  [ENGI_ACID]=JW_SMILE,[ENGI_BREAK]=JW_VINYL,[ENGI_CZ]=JW_GIRAFFE,
  [ENGI_PROPHET]=JW_GUST,[ENGI_S1]=JW_LIFTER,[ENGI_HYDRA]=JW_WIPER};
 return kind[e<NENGINES?e:0];
}
enum { PX_EDGE=1,PX_BODY,PX_SHADE,PX_ACCENT,PX_DEEP,PX_LIGHT,PX_FACE,PX_BLUSH,
       PX_PANEL,PX_GLASS,PX_STAGE,PX_GROUND,PX_GRASS };
typedef struct {
 int x,y,w,h,m[8],en,hit,notes,span,pitch,small,step,still,glide,age,lean;
 unsigned phase,ops;
 uint16_t palette[14];
} jw_context_t;
static jw_context_t jw;
#define PX_OP_LIMIT 430u

static void jw_tile(int x,int y,int w,int h,unsigned c)
{
 if(w<=0||h<=0||jw.ops>=PX_OP_LIMIT)return;
 int l=clamp(x,0,240)*jw.w/240,r=clamp(x+w,0,240)*jw.w/240;
 int t=clamp(y,0,112)*jw.h/112,b=clamp(y+h,0,112)*jw.h/112;
 if(r>l&&b>t){cv_rect(jw.x+l,jw.y+t,r-l,b-t,jw.palette[c]);jw.ops++;}
}
static void jw_path(int x,int y,int a,int b,unsigned c)
{
 if(jw.ops>=PX_OP_LIMIT)return;
 x=clamp(x,0,239);a=clamp(a,0,239);
 y=clamp(y,0,111);b=clamp(b,0,111);
 cv_line(jw.x+x*jw.w/240,jw.y+y*jw.h/112,jw.x+a*jw.w/240,jw.y+b*jw.h/112,jw.palette[c]);
 jw.ops++;
}
static void jw_sprite(unsigned id,int cx,int floor,int s,int flip)
{
 const uint8_t *run=JS_RUNS+JS_START[id];
 int ox=cx-16*s,oy=floor-28*s;
 for(int y=0;y<28;y++){
  int skip=jw.small&&(y&1);
  int row=ox+(y<20?jw.lean*(20-y)/20:0);
  for(int x=0;x<32;){
   unsigned data=*run++, color=data>>4;
   int width=(data&15)+1;
   if(color&&!skip){
    int left=flip?32-x-width:x;
    jw_tile(row+left*s,oy+y*s,width*s,s*(jw.small?2:1),color);
   }
   x+=width;
  }
 }
}
static int jw_sway(unsigned offset,int depth){return osc_sine(jw.phase+offset)*depth/32768;}
static void jw_stage(int floor,int speed)
{
 if(jw.small)return;
 jw_tile(13,floor,214,8,PX_STAGE);
 for(int i=0;i<5;i++){
  int x=13+((i*45+240-(int)(jw.phase>>25)*speed)&223);
  jw_tile(x,floor+2,12+speed*4,2,PX_GROUND);
 }
}
static void jw_spark(int x,int y)
{
 if(jw.small||jw.hit<24)return;
 int d=3+jw.hit/17;
 jw_tile(x-d,y,2*d+2,2,PX_ACCENT);
 jw_tile(x,y-d,2,2*d+2,PX_LIGHT);
 jw_tile(x-10-d,y+7,3,3,PX_GLASS);
}
static void jw_plant(unsigned sprite,int x,int floor,int lean)
{
 jw_tile(x-30,floor,60,3,PX_GROUND);
 jw.lean=lean;jw_sprite(sprite,x,floor,3,0);jw.lean=0;
}
static void jw_roll(int x,int y)
{
 int dx=jw_sway(jw.phase*3,6),dy=jw_sway(jw.phase*3+0x40000000u,6);
 jw_tile(x-26+dx,y+dy,3,3,PX_LIGHT);jw_tile(x+25+dx,y+dy,3,3,PX_LIGHT);
}
static void jw_duel(int fencing)
{
 int lunge=jw.hit*(16+jw.m[2]/8)/127;
 int right=(jw.step/2+jw.pitch)&1;
 int left=70+(!right?lunge:0), other=170-(right?lunge:0);
 int attack=lunge>5;
 int left_pose=attack?(right?1:2):0, right_pose=attack?(right?2:1):0;
 unsigned outfit=fencing?JS_FENCER0:JS_ATHLETE0;
 jw_sprite(outfit+left_pose,left,105,2,0);
 uint16_t main=jw.palette[PX_BODY],shade=jw.palette[PX_SHADE];
 jw.palette[PX_BODY]=jw.palette[PX_ACCENT];jw.palette[PX_SHADE]=jw.palette[PX_DEEP];
 jw.palette[PX_ACCENT]=main;jw.palette[PX_DEEP]=shade;
 jw_sprite(outfit+right_pose,other,105,2,1);
 jw.palette[PX_ACCENT]=jw.palette[PX_BODY];jw.palette[PX_DEEP]=jw.palette[PX_SHADE];
 jw.palette[PX_BODY]=main;jw.palette[PX_SHADE]=shade;
 /* The mirrored grip follows the visible glove in all three sprite poses. */
 int lx=left+16+4*left_pose, rx=other-18-4*right_pose;
 static const uint8_t grip_y[]={81,77,85};
 int target=71-jw.span/4;
 jw_path(lx,grip_y[left_pose],112+lunge/2,target,PX_GLASS);
 jw_path(rx,grip_y[right_pose],128-lunge/2,target+(!attack?5:0),PX_ACCENT);
}
/* Backdrops use four-byte marks. Coordinates are on a two-pixel grid. */
static void jw_backdrop(unsigned kind)
{
 if(jw.small)return;
 int wind=jw_sway(0,5);
 unsigned start=JS_BG_INDEX[kind][0], count=JS_BG_INDEX[kind][1];
 for(unsigned i=0;i<count;i++){
  const uint8_t *mark=JS_BG_MARKS[start+i];
  int dx=(mark[2]&128u)?wind:0;
  int x=(mark[0]&127u)*2+dx, y=(mark[1]&63u)*2;
  int a=(mark[2]&127u)*2, b=mark[3]*2;
  unsigned color=mark[0]&128u?PX_GROUND:PX_STAGE;
  if((mark[1]&64u)&&jw.hit>45&&((i+jw.step)&3u)==0)color=PX_GROUND;
  if(kind==JW_COW&&y>=90)color=PX_GRASS;
  if(mark[1]&128u)jw_path(x,y,a+dx,b,color);
  else jw_tile(x,y,a,b,color);
 }
}
static void jw_lift_arm(int shoulder,int sy,int wrist,int bar)
{
 int elbow=(shoulder+wrist)/2;
 int ey=(bar+sy)/2+clamp((bar-24)/4,0,7);
 for(int y=-2;y<=2;y++){
  unsigned col=(y==-2||y==2)?PX_EDGE:PX_FACE;
  jw_path(shoulder,sy+y,elbow,ey+y,col);
  jw_path(elbow,ey+y,wrist,bar+y,col);
 }
}
static void jw_scene(unsigned kind)
{
 int drift=jw_sway(0,4+jw.m[2]/15), hit=jw.hit/8;
 int jump=jw.hit*(10+jw.m[0]/9)/127;
 jw_backdrop(kind);
 switch(kind){
 case JW_DOG:
  jw_stage(100,1);jw_plant(jw_sway(jw.phase*2,4)>0?JS_DOG_STEP:JS_DOG,116+drift*3,101,hit/2+drift);
  for(int k=0;k<jw.notes;k++)jw_tile(35+k*48,105,9,2,PX_ACCENT);
  break;
 case JW_CAT:{
  int string=(jw.pitch+28)&3, grab=jw.age<75;
  int bend=hit+jw.en/18+jw.m[2]/13, pluck=grab?bend/2:jw_sway(0,bend/3);
  int paw=grab?165:151, py=50+string*9+(grab?pluck:5);
  jw_stage(103,0);jw_tile(213,43,4,51,PX_SHADE);
  for(int k=0;k<4;k++){
   int y=50+k*9, offset=k==string?pluck:0;
   jw_path(150,y,165,y+offset,PX_GROUND);
   jw_path(165,y+offset,214,y,PX_GLASS);
  }
  jw_plant(drift>0?JS_CAT_STEP:JS_CAT,108,104,jw.en/15+drift/2);
  int wrist=paw-17, elbow=(130+wrist)/2;
  for(int d=-3;d<=3;d++){
   unsigned fur=(d==-3||d==3)?PX_EDGE:PX_BODY;
   jw_path(126,76+d,elbow,84+d,fur);
   jw_path(elbow,84+d,wrist,py+d,fur);
  }
  jw_sprite(JS_PAW,paw-10,py+14,2,0);
  break;
 }
 case JW_DRYER:
  jw_plant(JS_DRYER,81,97,drift+jw.en/18);
  for(int k=0;k<5;k++){
   int x=129+(int)((jw.phase>>(24+k%2))&31)+k*8;
   jw_tile(x,47+k*7+jw_sway(k*0x30000000u,3),10+jw.m[4]/9+jw.en/8,3,k&1?PX_ACCENT:PX_GLASS);
  }
  break;
 case JW_BOXER:
  jw_stage(104,0);
  for(int k=0;k<3;k++)jw_path(25,69+k*10,215,69+k*10+jw.hit/34,PX_GROUND);
  jw_tile(169+hit/2,27,2,34,PX_GROUND);
  jw_tile(155+hit/2,54,29,42,PX_EDGE);jw_tile(158+hit/2,57,23,36,PX_SHADE);
  jw_tile(160+hit/2,60,6,29,PX_ACCENT);
  jw_plant(JS_ATHLETE0+(hit>7?2:hit>3?1:0),106,106,hit+drift/2);
  jw_spark(155+hit/3,69);break;
 case JW_FIRE:{
  int sway=jw_sway(0,5+jw.m[2]/11)+hit/2;
  jw_stage(105,0);jw_plant(JS_FIRE,120,106,sway);
  for(int i=0;i<4;i++){
   int y=49-i*8-((int)(jw.phase>>27)+i*5)%19-hit/2;
   jw_tile(96+i*15+sway,y,2+hit/8,3,i&1?PX_ACCENT:PX_FACE);
  }
  break;
 }
 case JW_ROCKET:{
  int x=120+drift,y=104-jump-jw.en/7;
  jw_stage(106,0);
  jw_tile(x-8,y-9,13,5+jw.en/10,PX_ACCENT);
  jw_tile(x-5,y-9,7,3+jw.en/13,PX_LIGHT);
  jw_sprite(JS_ROCKET,x,y,3,0);
  break;
 }
 case JW_COCKPIT:
  jw_sprite(JS_COCKPIT,120,115,5,0);
  for(int k=0;k<8;k++)jw_tile(79+(k*23+(jw.phase>>25))%80,30+(k*9)%19,2,2,PX_GLASS);
  jw_path(102,48,140,48+drift,PX_LIGHT);jw_tile(119,45+drift/2,4,7,PX_ACCENT);
  break;
 case JW_MOOSE:
  jw_stage(105,0);jw_plant(JS_MOOSE,120+drift,106,2*drift+hit/2);
  for(int i=0;i<jw.notes;i++)jw_tile(54+i*39,14+i%2*7,3,4+jw.span/5,PX_ACCENT);
  break;
 case JW_BIRD:{
  /* A fresh note closes the gap. The envelope widens the chase and lets
   * both paths contract to their resting positions on release. */
  int energy=jw.en, range=energy/2;
  unsigned dash=(unsigned)jw.hit<<21;
  int turn=jw_sway(0x40000000u+dash,32);
  int x=102+energy/8+jw_sway(dash,range);
  int y=103-energy/4+jw_sway(0x40000000u+dash,energy*(16+jw.m[4]/10)/128);
  unsigned escape=0x26000000u+dash/2;
  int prey=145-energy/8+jw_sway(escape,range+energy/8);
  int py=68-energy/8+jw_sway(0x40000000u+escape,energy/6);
  unsigned wings=energy>4&&((jw.phase>>28)&1u);
  jw_sprite(JS_BIRD0+wings,x,y,2,turn<0);
  jw_tile(prey-3,py-3-(int)wings,8,3,PX_LIGHT);
  jw_tile(prey,py,4,4,PX_ACCENT);
  break;
 }
 case JW_SKATER:{
  int x=124+drift, y=104-jump;
  jw_stage(108,2);
  jw_tile(x-25,y-1,8,6,PX_SHADE);jw_tile(x+20,y-1,8,6,PX_SHADE);
  jw_tile(x-36,y-6,69,5,PX_EDGE);jw_tile(x-32,y-5,62,2,PX_ACCENT);
  /* Draw boots over the upper deck so the contact reads in both palettes. */
  jw.lean=drift+jw.en/16;
  jw_sprite(JS_SKATER0+(hit>5),x,y+1,3,0);
  jw.lean=0;
  if(hit>5)jw_spark(x-33,105);break;
 }
 case JW_WIZARD:{
  int x=96+drift, hand=130+hit, hy=78-hit, tip=hand+8+hit*2, ty=38-hit;
  jw_stage(105,0);jw_sprite(JS_WIZARD,x,105,3,0);
  jw_path(x+13,74,hand,hy,PX_EDGE);jw_path(x+13,75,hand,hy+1,PX_BODY);
  int base=hand-(tip-hand)/2, by=hy+(hy-ty)/2;
  jw_path(base,by,tip,ty,PX_SHADE);jw_path(base+1,by,tip+1,ty,PX_LIGHT);
  jw_tile(hand-3,hy-2,7,6,PX_FACE);jw_tile(tip-3,ty-3,8,8,PX_ACCENT);
  jw_spark(tip,ty);
  if(!jw.small)for(int i=0;i<5;i++){
   unsigned a=jw.phase+i*0x33333333u;
   int r=11+jw.m[1]/9+jw.en/12+hit*(i+2)/5;
   int px=tip+11+osc_sine(a)*r/32768, py=ty+osc_sine(a+0x40000000u)*r/32768;
   jw_tile(px,py,3+jw.notes/2,3,i&1?PX_GLASS:PX_LIGHT);
  }
  break;}
 case JW_COW:{
  int lift=jw.age<192?jw.age*(192-jw.age)*hit/8192:0;
  jw_stage(104,0);jw_plant(JS_COW,120+2*drift,106-lift,drift-jw.en/12);
  for(int k=0;k<4;k++)jw_tile(34+k*55,105-((jw.phase>>(k+25))&3),4,5,PX_BODY);
  break;}
 case JW_FENCE:case JW_SPAR:
  jw_stage(106,0);jw_duel(kind==JW_FENCE);break;
 case JW_PRESS:{
  int y=53+jw.en/9;
  jw_sprite(JS_PRESS,120,112,4,0);
  jw_tile(112,41,15,y-37,PX_GLASS);jw_tile(93,y,54,6,PX_BODY);
  for(int k=0;k<4;k++)jw_tile(99+k*10,y+9+(k&1)*3,8,16-jump/2,k&1?PX_LIGHT:PX_ACCENT);
  jw_spark(120,82);break;
 }
 case JW_PLANE:{
  int x=120+jw_sway(0,65), y=78+jw_sway(0x40000000u,13+jw.m[4]/12)-hit;
  int left=jw_sway(0x40000000u,16)<0;
  jw_sprite(JS_PLANE,x,y,2,left);
  for(int i=0;i<3;i++){
   int dx=35+i*15;
   jw_tile(x+(left?dx:-dx),y-26+i*2,6+i*3,2,PX_GROUND);
  }
  break;
 }
 case JW_COASTER:{
  int depth=13+jw.m[4]/13, px=120, py=84+depth;
  for(unsigned i=1;i<=16;i++){
   unsigned angle=i*0x10000000u;
   int x=120+osc_sine(angle)*74/32768;
   int y=84+osc_sine(angle+0x40000000u)*depth/32768;
   jw_path(px,py,x,y,PX_GROUND);
   px=x;py=y;
  }
  int x=120+jw_sway(0,74), turn=jw_sway(0x40000000u,depth);
  jw_sprite(JS_COASTER,x,86+turn,2,turn<0);break;
 }
 case JW_SNAIL:
  jw_stage(104,0);jw_plant(JS_SNAIL,110+drift*3,105,jw.en/8+drift);
  jw_tile(58+drift*2,105,12+jw.m[2]/6,2,PX_ACCENT);break;
 case JW_CLOCKS:
  for(int i=0;i<2;i++){
   int x=71+i*98, y=63;
   unsigned a=(unsigned)(jw.still?0:jw.age)*(0x00900000u+i*jw.m[2]*0x20000u);
   jw_sprite(JS_CLOCK,x,100,3,0);
   jw_path(x,y,x+osc_sine(a)*18/32768,y-osc_sine(a+0x40000000u)*19/32768,i?PX_ACCENT:PX_PANEL);
   jw_tile(x-2,y-2,4,4,PX_EDGE);
  }break;
 case JW_BALL:{
  int x=126+jw.hit*(20+jw.m[2]/7)/127,y=105-hit;
  jw_stage(107,0);jw_tile(32,18,5,86,PX_SHADE);jw_tile(32,17,92,5,PX_BODY);
  jw_path(120,22,x,y-54,PX_GLASS);jw_sprite(JS_WRECK,x,y,2,0);
  for(int k=0;k<6;k++)jw_tile(166+k%2*17+hit/3*(k%3),93-k/2*13-hit/3,14,10,k&1?PX_SHADE:PX_GLASS);
  jw_spark(x+16,y-14);break;
 }
 case JW_VACUUM:{
  int x=60+drift, tip=165+jw.m[2]/8-hit/2;
  jw_stage(105,0);jw_sprite(JS_VACUUM,x,105,3,0);
  jw_path(x+32,71,130,53,PX_GLASS);jw_path(130,53,tip,94,PX_GLASS);
  jw_tile(tip-12,91,27,8,PX_EDGE);jw_tile(tip-10,92,24,4,PX_BODY);
  for(int i=0;i<4;i++)jw_tile(tip+20+i*10-(hit+i)%8,102-i%2*4,4,3,PX_ACCENT);
  break;
 }
 case JW_FAN:
  jw_stage(105,0);jw_plant(JS_PEACOCK,120,105,drift+jw.en/12);
  for(int i=0;i<jw.notes;i++)jw_tile(67+i*34,23-jw_sway(i*0x20000000u,5),3,3,PX_ACCENT);
  break;
 case JW_SWORD:{
  int pose=jw.age<52?1:jw.age<138?2:0;
  int x=104+(pose==2?9:0), hand=x+21+pose*3+(pose==2?6:0);
  int hy=22+(pose==1?9:pose==2?17:16)*3;
  unsigned a=pose?(unsigned)clamp((jw.age-28)*128/86,0,128)*0x007a0000u-0x27000000u:0xe8000000u;
  int tx=hand+osc_sine(a+0x40000000u)*57/32768,ty=hy+osc_sine(a)*57/32768;
  jw_stage(105,0);jw_sprite(JS_SWORD0+pose,x,106,3,0);
  for(int i=-2;i<=2;i++)jw_path(hand,hy+i,tx,ty+i,i==-2||i==2?PX_EDGE:i==0?PX_LIGHT:PX_GLASS);
  jw_tile(hand-2,hy-4,5,9,PX_ACCENT);
  if(pose==2&&!jw.small){
   jw_path(tx-12,ty-22,tx-2,ty-7,PX_GROUND);
   jw_path(tx-2,ty-7,tx+3,ty+1,PX_GLASS);
   jw_spark(tx+2,ty);
  }
  break;}
 case JW_VINYL:{
  jw_sprite(JS_DECK,115,112,4,0);
  int ax=152,ay=31, tx=115-jw.step/2,ty=64-hit/4;
  jw_path(ax,ay,tx+8,ty-6,PX_LIGHT);jw_path(tx+8,ty-6,tx,ty,PX_LIGHT);
  jw_tile(tx-3,ty-2,7,5,PX_ACCENT);
  int dx=jw_sway(0,29),dy=jw_sway(0x40000000u,27);
  jw_tile(99+dx,54+dy,4,3,PX_LIGHT);
  if(jw.en)jw_tile(127+((jw.step>>2)&3)*12,88,8,8,PX_ACCENT);
  break;
 }
 case JW_LIFTER:{
  /* Acceleration, a brief lockout, then a controlled return. Feet stay planted. */
  int phase=jw.age<100?jw.age:jw.age<150?100:jw.age<350?(350-jw.age)/2:0;
  int y=79-phase*(55+jw.m[3]/13)/100;
  int pose=phase>=70?2:phase>=32?1:0;
  int sy=76-pose*9;
  jw_stage(107,0);jw_sprite(JS_LIFTER0+pose,120,106,3,0);
  jw_lift_arm(100,sy,88,y);jw_lift_arm(140,sy,152,y);
  jw_tile(53,y-2,134,5,PX_EDGE);jw_tile(55,y,130,2,PX_GLASS);
  for(int side=0;side<2;side++){
   int x=57+side*110;
   jw_tile(x,y-12,15,25,PX_EDGE);jw_tile(x+2,y-10,11,21,PX_DEEP);
   jw_tile(x+4,y-8,6,16,PX_ACCENT);jw_tile(x+5,y-8,3,3,PX_LIGHT);
  }
  jw_tile(85,y-3,7,6,PX_EDGE);jw_tile(86,y-2,5,4,PX_FACE);
  jw_tile(149,y-3,7,6,PX_EDGE);jw_tile(150,y-2,5,4,PX_FACE);
  if(phase==100)jw_spark(118,y-7);
  break;
 }
 case JW_RIDER:{
  int x=123+drift*2+hit,y=105;
  jw_stage(108,3);
  jw.lean=jw.en/12;jw_sprite(JS_SKATER0+(hit>7),x+1,y-37,2,0);jw.lean=0;
  jw_sprite(JS_BIKE,x,y,3,0);jw_roll(x,y-24);
  break;
 }
 case JW_GIRAFFE:
  jw_stage(106,0);jw_plant(JS_GIRAFFE,119,106,drift+jw.en/10);
  for(int i=0;i<5;i++)jw_tile(177,27+i*13,i==jw.notes?13:7,2,i==jw.notes?PX_ACCENT:PX_GROUND);
  break;
 case JW_RACER:{
  int x=119+hit+drift;
  jw_stage(105,3);jw_sprite(JS_RACER,x,104,3,0);jw_roll(x,84);
  jw_tile(x+43,63,9+jw.m[2]/9,3,PX_LIGHT);
  if(hit>5)jw_tile(x-65,77,17,3,PX_ACCENT);break;
 }
 case JW_GUST:
  jw_stage(106,0);jw_tile(53,24,5,81,PX_SHADE);
  for(int k=0;k<8;k++){
   int x=56+k*(10+jw.m[6]/25),y=40+jw_sway(k*0x19000000u,4+k+jw.en/22);
   int h=29-k*3;
   jw_tile(x,y-h/2,11+jw.m[6]/25,h,PX_EDGE);
   jw_tile(x+1,y-h/2+2,10+jw.m[6]/25,h-3,k&1?PX_ACCENT:PX_BODY);
  }break;
 case JW_WIPER:{
  jw_sprite(JS_SCREEN,120,116,5,0);
  int x=121+jw_sway(0,40),y=39+jw.m[0]/12;
  for(int k=0;k<10;k++){
   int px=58+(k*29+(jw.phase>>25))%117,py=29+k*5%40;
   if(px<x-13||px>x+13)jw_tile(px,py,2,4,PX_GLASS);
  }
  int px=57,py=51;
 for(int k=1;k<=14;k++){
  int xx=57+k*9,yy=51+jw_sway(k*(0x12000000u+jw.m[0]*0x100000u),4+jw.m[1]/9);
  jw_path(px,py,xx,yy,PX_BODY);px=xx;py=yy;
 }
 jw_path(120,75,x,y,PX_LIGHT);jw_path(x-11,y-3,x+11,y+3,PX_LIGHT);
  jw_tile(118,72,5,5,PX_ACCENT);break;
 }
 case JW_SMILE:{
  static const uint8_t contour[]={12,23,30,35,39,41,43,44,45,45,45,44,43,41,38,34,29,22,11};
  int x=119+jw.pitch/3,y=47, melt=hit+jw.m[0]/11;
  if(!jw.small)for(int ring=0;ring<3;ring++){
   int px=x,py=y,rx=51+ring*20+hit,ry=12+ring*9+jw.m[1]/13;
   for(unsigned i=0;i<=12;i++){
    unsigned a=i*0x15555555u+(jw.phase>>2);
    int ax=x+osc_sine(a)*rx/32768,ay=y+8+osc_sine(a+0x40000000u)*ry/32768;
    if(i)jw_path(px,py,ax,ay,ring?PX_STAGE:PX_DEEP);
    px=ax;py=ay;
   }
  }
  for(int k=0;k<19;k++){
   int r=contour[k]*(103+jw.m[0]/5)/128, wobble=jw_sway(k*0x0a000000u,2+melt/3);
   jw_tile(x+wobble-r,y-28+k*3,2*r,3,PX_EDGE);
   if(k&&k<18)jw_tile(x+wobble-r+2,y-28+k*3,2*r-4,3,k>13?PX_BLUSH:PX_FACE);
  }
  for(int k=0;k<5;k++){
   int dx=x-26+k*12, d=8+melt*(1+k%3)/3+jw_sway(k*0x40000000u,4);
   jw_tile(dx,69,5+(k&1)*2,d,k&1?PX_BLUSH:PX_FACE);
   if(!jw.small)jw_tile(dx+1,71+d+(int)jw.age/34,3,3,PX_FACE);
  }
  int wink=jw_sway(0x50000000u,3+jw.m[1]/41);
  jw_tile(x-17,38+wink,6,13+hit/3,PX_EDGE);
  jw_tile(x+11,38-wink,6,13+hit/3,PX_EDGE);
  jw_tile(x-23,28,10,3,PX_LIGHT);jw_tile(x-28,31,4,6,PX_LIGHT);
  for(int k=0;k<11;k++){
   int yy=54+k*(10-k)/3+hit/3+wink*(5-k)/5;
   jw_tile(x-22+k*4,yy,5,4,PX_EDGE);
  }
  jw_tile(x-30-melt,102,60+2*melt,3,PX_DEEP);
  jw_tile(x-18-hit,101,31+2*hit,2,PX_BLUSH);
  if(jw.glide)jw_path(x-64,78,x-39,74,PX_ACCENT);
  break;
 }
 }
}
/* Main scene affordance: the engine's EDIT index that shapes the demo's world. */
static const uint8_t JW_KNOB[]={2,2,4,0,2,2,2,2,4,0,1,3,3,5,4,4,2,2,2,2,2,2,2,3,2,2,2,2,6,0,0};
static void jw_draw(const track_t *t,unsigned e,int en,unsigned ph,int x,int y,int w,int h,uint16_t ink){
 if(e>=NENGINES||e==ENGI_EMPTY){cv_frame(x+w/2-3,y+h/2-3,6,6,T_DIM);return;}
 unsigned kind=jazzy_object(e);
 jw=(jw_context_t){.x=x,.y=y,.w=w,.h=h,.small=w<100,.age=400};
 jw.still=!!(ui_prefs&PREF_ANIM_OFF)||ink==T_DIM||(t&&t->p[P_MUTE]);
 static const uint16_t paint[][4]={
  {0x6db6,0x344e,0xed67,0xa343}, /* arcade amber */
  {0x657b,0x31b1,0xf32b,0x9227}, /* pool blue and coral */
  {0x7cf5,0x42ae,0xd6a9,0x8405}, /* leaf and ochre */
  {0xa53c,0x5a32,0xf5b0,0xb2eb}, /* periwinkle and peach */
  {0xadd6,0x630d,0xeca5,0xa263}, /* enamel and tangerine */
  {0xe64a,0xab85,0xe39c,0x8a70}, /* acid honey and magenta */
 };
 static const uint8_t material[]={0,3,1,1,4,4,1,0,1,1,3,4,1,4,3,1,
  2,1,1,4,2,3,4,1,1,0,1,3,2,1,5};
 unsigned colors=material[kind];
 jw.palette[PX_EDGE]=0x0841;
 for(unsigned i=0;i<4;i++)jw.palette[PX_BODY+i]=paint[colors][i];
 jw.palette[PX_LIGHT]=0xff9b;jw.palette[PX_FACE]=0xfe36;jw.palette[PX_BLUSH]=0xdd10;
 jw.palette[PX_PANEL]=0x2128;jw.palette[PX_GLASS]=0x8df4;
 jw.palette[PX_STAGE]=ux_mix(T_BG,T_TEXT,18);jw.palette[PX_GROUND]=ux_mix(T_BG,T_TEXT,32);
 if(kind==JW_COW)jw.palette[PX_GRASS]=ux_mix(T_BG,0x6688,52);
 if(kind==JW_SMILE){jw.palette[PX_FACE]=0xff08;jw.palette[PX_BLUSH]=0xe4c4;}
 if(ink==T_DIM){
  for(unsigned i=PX_BODY;i<=PX_GLASS;i++)jw.palette[i]=ux_mix(T_BG,T_TEXT,i&1?27:53);
  jw.palette[PX_EDGE]=T_BG;
 }
 for(unsigned k=0;k<8;k++){
  const param_desc_t *p=&ENGINES[e]->edit[k];int v=t?t->p[P_E0+k]:p->def,range=p->max-p->min;
  jw.m[k]=range>0?clamp((v-p->min)*127/range,0,127):0;
 }
 int pitch=60,lo=128,hi=0;
 if(!jw.still){
  /* The workstation level follows active envelopes, including release. */
  jw.phase=ph;jw.en=en;
  if(t){
   unsigned at=six_vis_note_at[t-trk],age=at?fm1_ms-(at-1u):400;
   jw.age=age<400?(int)age:400;
   jw.hit=jw.age<290?(290-jw.age)*(40+six_vis_note_vel[t-trk]*87/127)/290:0;
   int step=e==ENGI_BREAK?jungle_current_step():-1;
   jw.step=step>=0?step:t->seq_idx;jw.glide=t->slide_glide;
   unsigned held=t->nheld,mono=t->nmono;
   if(held>16)held=16;if(mono>8)mono=8;
   if(held||mono){
    const uint8_t *nn=held?t->held:t->mono_stack;
    for(unsigned k=0;k<(held?held:mono);k++){int n=nn[k];if(n<lo)lo=n;if(n>hi)hi=n;jw.notes++;}
   }else for(unsigned k=0;k<NVOICE;k++)if(t->v[k].active&&t->v[k].gate){
    int n=t->v[k].note;
    if(n<lo||n>hi)jw.notes++;
    if(n<lo)lo=n;if(n>hi)hi=n;
   }
   if(hi>=lo)pitch=lo;
   if(t->nmono&&t->mono_note)pitch=t->mono_note;
  }else jw.hit=en;
 }
 jw.span=clamp(hi-lo,0,24);jw.notes=clamp(jw.notes,1,4);jw.pitch=clamp(pitch-60,-28,28);
 jw_scene(kind);
}
#undef PX_OP_LIMIT
