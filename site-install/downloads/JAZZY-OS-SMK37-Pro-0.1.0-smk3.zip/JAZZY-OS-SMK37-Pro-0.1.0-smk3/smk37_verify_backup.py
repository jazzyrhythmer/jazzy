#!/usr/bin/env python3
"""Read-only verification of two original SMK-37 Pro raw flash backups."""
from pathlib import Path
import sys,hashlib
if len(sys.argv)!=3:raise SystemExit('Usage: python smk37_verify_backup.py dump1.bin dump2.bin')
a,b=(Path(x).read_bytes()for x in sys.argv[1:])
if len(a)!=1048576 or len(b)!=1048576:raise SystemExit('FAIL: each dump must be exactly 1,048,576 bytes')
if a!=b:raise SystemExit('FAIL: dumps differ; read the flash again')
if a[0xC1224:0xC122B]!=b'trimdat':raise SystemExit('FAIL: Pro calibration marker missing; do not rely on these dumps')
print('PASS: identical 1 MiB backups with Pro calibration marker\nSHA256 '+hashlib.sha256(a).hexdigest())
