/* SPDX-License-Identifier: GPL-3.0-only */
static void smk_audit_cases(void)
{
 static const uint8_t buttons[SEC_N]={B_HOME,B_EDIT,B_SEQ,B_FX,B_GLO,B_ENV,B_LFO,B_SCL,B_ARP,B_SAVE};
 unsigned pages=0,engines=0;
 for(unsigned e=0;e<NENGINES;e++) {
  if(!eng_ok(e))continue;
  setup();set_engine_of(TSEL,e);TSEL->engine=TSEL->eng_req;engines++;
  for(unsigned load=0;load<=LOAD_ECO;load++) {
   load_put(LOAD_ECO-load);
   for(unsigned sec=0;sec<SEC_N;sec++) {
    const ch_t *ch=nav_ch(sec);unsigned first=0;
    while(first<ch->n&&!nv_ok(sec,first))first++;
    if(first==ch->n)continue;
    nav_go(sec,first,0);
    for(unsigned k=first+1;k<=ch->n;k++) {
     unsigned want=k==ch->n?first:k;if(!nv_ok(sec,want))continue;
     press(buttons[sec]);
     if(nav_sec()!=sec||nav_cur()!=want){fprintf(stderr,"PAGE FAIL engine=%u load=%u section=%u wanted=%u got=%u\n",e,load,sec,want,nav_cur());must(0,"physical page button reaches every eligible page");}
     pages++;
    }
   }
  }
 }
 unsigned roundtrips=0;
 for(unsigned e=0;e<NENGINES;e++){
  if(!eng_ok(e)||e==ENGI_EMPTY||!ENGINES[e]->npresets)continue;
  unsigned count=ENGINES[e]->npresets,picks[3]={0,count/2,count-1};
  for(unsigned k=0;k<3;k++){
   if(k&&picks[k]==picks[k-1])continue;
   setup();set_engine_of(TSEL,e);apply_preset_to(TSEL,picks[k]);TSEL->engine=TSEL->eng_req;
   const param_desc_t *d=param_desc_of(e,P_E0);if(d->max>d->min)TSEL->p[P_E0]=TSEL->p[P_E0]<d->max?TSEL->p[P_E0]+1:d->min;
   int16_t expected[8];memcpy(expected,TSEL->p+P_E0,sizeof expected);
   must(up_store(0,"AUDIT")==3,"user sound stores for every selectable engine");set_engine_of(TSEL,ENGI_ANALOG);must(up_load(0)==0,"user sound reloads");
   if(TSEL->eng_req!=e||memcmp(expected,TSEL->p+P_E0,sizeof expected)){fprintf(stderr,"SAVE FAIL e=%u preset=%u user sound\n",e,picks[k]);must(0,"edited controls survive user sound roundtrip");}
   must(project_save(0)==0,"project stores for every selectable engine");set_engine_of(TSEL,ENGI_ANALOG);project_load(0);
   if(TSEL->eng_req!=e||memcmp(expected,TSEL->p+P_E0,sizeof expected)){fprintf(stderr,"SAVE FAIL e=%u preset=%u project\n",e,picks[k]);must(0,"edited controls survive project roundtrip");}
   roundtrips++;
  }
 }
 printf("SMK_SAVE_AUDIT_PASS: %u edited sound and project roundtrips across selectable engines\n",roundtrips);
 setup();
 must(panel.btn[B_PLAY]==16&&panel.btn[B_REC]==17&&panel.btn[B_FX]==14&&panel.btn[B_SEQ]==15,"upper four physical buttons have correct roles");
 for(unsigned cycle=0;cycle<32;cycle++) {
  song.g[G_CLOCK]=0;press(B_PLAY);must(transport_req==1,"PLAY start request");events_block(CTL);must(song.playing&&transport_req==0,"audio control block starts playback");
  press(B_PLAY);must(transport_req==2,"PLAY stop request");events_block(CTL);must(!song.playing&&transport_req==0,"audio control block stops playback");
 }
 setup();song.playing=1;ui.menu=1;press(B_PLAY);events_block(CTL);must(!song.playing&&ui.menu,"STOP works without leaving the menu");
 setup();song.playing=1;ui.confirm=CF_OVR_PROJ;press(B_PLAY);events_block(CTL);must(!song.playing&&ui.confirm==CF_OVR_PROJ,"STOP never accepts or closes a save confirmation");
 setup();ui.menu=1;press(B_PLAY);must(!transport_req&&!song.playing,"PLAY never starts playback inside a menu");
 setup();press(B_REC);events_block(CTL);must(song.playing,"REC enters running transport");press(B_PLAY);events_block(CTL);must(!song.playing,"PLAY stops a recording-started transport");
 setup();song.playing=1;scrn.st=SCR_OFF;press(B_PLAY);events_block(CTL);must(!song.playing&&scrn.st!=SCR_OFF,"first PLAY press stops playback and wakes the screen");
 printf("SMK_AUDIT_PASS: %u engines / %u physical page transitions; 32 audio-controlled start-stop cycles; menu/dialog/REC stop paths\n",engines,pages);
}
