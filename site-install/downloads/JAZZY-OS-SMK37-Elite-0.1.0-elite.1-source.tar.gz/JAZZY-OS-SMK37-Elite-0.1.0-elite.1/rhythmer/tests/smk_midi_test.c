/* SPDX-License-Identifier: GPL-3.0-only. Actual TX queue against a paced UART and MIDI receiver. */
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static uint8_t wire[200000];static unsigned used,tick,ready_at,delay_ticks=4,dead;
static void smk_uart_tx_init(void){ready_at=tick;}
static void smk_uart_tx_restart(void){ready_at=tick;}
static int smk_uart_tx_done(void){return !dead&&tick>=ready_at;}
static void smk_uart_tx_byte(uint8_t b){if(used>=sizeof wire)abort();wire[used++]=b;ready_at=tick+delay_ticks;}
#define __attribute__(x)
#include "../firmware/src/smk_midi_out.h"
#undef __attribute__
static void ok(int a,const char*s){if(!a){fprintf(stderr,"FAIL %s tick=%u bytes=%u\n",s,tick,used);exit(1);}}
static void poll(unsigned n){while(n--){tick++;smk_midi_out_poll();}}
static void reset(void){used=tick=dead=0;delay_ticks=4;smk_midi_init();}
static uint32_t msg(unsigned s,unsigned a,unsigned b){return(s>>4)|(s<<8)|(a<<16)|(b<<24);}
static unsigned notes[16][128],parse_status,parse_data[2],parse_pos,parse_need,malformed,last_transport;
static void receive(void){
 memset(notes,0,sizeof notes);parse_status=parse_pos=parse_need=malformed=last_transport=0;
 for(unsigned i=0;i<used;i++){
  unsigned b=wire[i];if(b>=248){if(b>=250&&b<=252)last_transport=b;continue;}
  if(b&128){if(parse_pos)malformed++;parse_status=b;parse_pos=0;parse_need=((b&0xE0)==0xC0)?1:2;if(b>=240)parse_need=b==241||b==243?1:b==242?2:0;continue;}
  if(!parse_status||!parse_need){malformed++;continue;}parse_data[parse_pos++]=b;
  if(parse_pos==parse_need){unsigned c=parse_status&15,s=parse_status&240,a=parse_data[0],v=parse_data[1];
   if(s==144)notes[c][a]=v!=0;if(s==128)notes[c][a]=0;
   if(s==176&&(a==120||a==123))memset(notes[c],0,sizeof notes[c]);
   parse_pos=0;
  }
 }
}
int main(void){
 reset();smk_midi_out_packet(msg(0x90,60,100));poll(1);smk_midi_out_packet(0xF8u<<8|15u);poll(20);
 ok(used==4&&wire[0]==0x90&&wire[1]==0xF8&&wire[2]==60&&wire[3]==100,"realtime interleaves complete note bytes");
 smk_midi_out_packet(msg(0x80,60,0));poll(20);receive();ok(!malformed&&!notes[0][60],"note-off ends external receiver note");
 reset();uint32_t p[]={msg(0xC2,11,255),msg(0xD2,99,255),msg(0xB2,1,100),msg(0xE2,0,64),0xF1u<<8|0x05u<<16|2u,0xF2u<<8|0x04u<<16|0x05u<<24|3u,0xF6u<<8|5u};
 for(unsigned i=0;i<sizeof p/sizeof p[0];i++)smk_midi_out_packet(p[i]);poll(150);ok(used==16,"CIN-specific program/pressure/CC/bend/system-common lengths");
 unsigned before=used;smk_midi_out_packet(msg(0xFF,60,100)&~15u|9u);smk_midi_out_packet(msg(0x90,128,100));for(unsigned c=4;c<=7;c++)smk_midi_out_packet(0xF0u<<8|c);poll(100);ok(used==before,"invalid status, data and updater SysEx never leave TRS");
 reset();smk_midi_out_packet(msg(0x91,61,110));poll(20);
 for(unsigned i=0;i<65;i++)smk_midi_out_packet(msg(0x90,i%128,100));ok(smk_midi.panic&&smk_midi.overflows==1,"overflow requests receiver panic");poll(1000);receive();ok(!malformed&&!parse_pos,"overflow never truncates a MIDI message");
 for(unsigned c=0;c<16;c++)for(unsigned n=0;n<128;n++)ok(!notes[c][n],"overflow leaves no external notes held");ok(!smk_midi.panic,"panic completes and output resumes");
 smk_midi_out_packet(msg(0x90,62,90));smk_midi_out_packet(msg(0x80,62,0));poll(40);receive();ok(!notes[0][62],"fresh notes work after recovery");
 reset();smk_midi_out_packet(msg(0x90,60,100));poll(1);for(unsigned i=0;i<65;i++)smk_midi_out_packet(msg(0x90,i,90));poll(1000);receive();ok(!malformed&&!parse_pos&&!notes[0][60],"overflow during a partly transmitted note finishes that message first");
 reset();smk_midi_out_packet(msg(0x90,60,100));poll(20);smk_midi_set_enabled(0);smk_midi_out_packet(0xFCu<<8|15u);smk_midi_out_packet(msg(0xB0,1,127));poll(1000);receive();ok(!notes[0][60]&&last_transport==0xFC&&!smk_midi.panic,"MIDI OFF ends held keys and retains STOP");before=used;smk_midi_out_packet(msg(0xE0,0,0));poll(20);ok(before==used,"MIDI OFF suppresses wheels too");
 smk_midi_set_enabled(1);poll(1000);smk_midi_out_packet(msg(0x90,63,95));smk_midi_out_packet(msg(0x80,63,0));poll(40);receive();ok(!notes[0][63],"re-enable recovers normal output");
 reset();for(unsigned i=0;i<16;i++)smk_midi_out_packet(0xF8u<<8|15u);smk_midi_out_packet(0xFAu<<8|15u);smk_midi_out_packet(0xFCu<<8|15u);poll(100);receive();ok(last_transport==0xFC,"STOP survives a full realtime queue");
 reset();smk_midi_out_packet(msg(0x90,60,100));dead=1;poll(200);ok(smk_midi.fault&&smk_midi.timeouts==4,"missing UART stops after bounded nonblocking retries");before=used;poll(1000);ok(used==before,"faulted UART cannot stall or spin on audio path");dead=0;smk_midi_set_enabled(1);poll(1000);ok(!smk_midi.fault&&!smk_midi.panic,"mode selection recovers stalled UART");
 reset();smk_midi.w=smk_midi.r=65530u;smk_midi.rw=smk_midi.rr=250u;
 for(unsigned i=0;i<2000;i++){smk_midi_out_packet(msg(0x90,i%128,70));smk_midi_out_packet(msg(0x80,i%128,0));smk_midi_out_packet(0xF8u<<8|15u);poll(35);}receive();ok(!malformed&&!parse_pos&&!smk_midi.overflows,"normal and realtime counters wrap safely");
 printf("SMK_TRS_MIDI_PASS: wire parsing, realtime, complete messages, overflow panic, OFF/STOP, UART timeout/recovery, ring wrap; state %zu bytes\n",sizeof smk_midi);return 0;
}
