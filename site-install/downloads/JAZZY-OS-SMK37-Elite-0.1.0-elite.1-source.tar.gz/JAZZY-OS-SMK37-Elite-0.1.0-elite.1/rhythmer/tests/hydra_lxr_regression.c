#define UI_TEST_NO_MAIN 1
#include "jazzy_host.h"
static track_t *setup(unsigned preset){track_t*t=&trk[0];set_engine_of(t,ENGI_LXR);apply_preset_to(t,preset);t->engine=t->eng_req;t->xf=t->xf_on=t->xin=0;memset(t->v,0,sizeof t->v);t->nmono=0;t->p[P_DIST]=t->p[P_CHOR]=t->p[P_DLY]=t->p[P_REV]=0;memset(tf_on,0,sizeof tf_on);memset(tf_xb,0,sizeof tf_xb);memset(tf_ic1,0,sizeof tf_ic1);memset(tf_ic2,0,sizeof tf_ic2);return t;}
static double render_env(unsigned attack,unsigned release,unsigned cut){track_t*t=setup(0);t->p[P_E2]=127;t->p[P_ATK]=attack;t->p[P_REL]=release;t->p[P_FCUT]=cut;trk_note_on(t,60,100);double energy=0;for(unsigned b=0;b<128;b++){int32_t out[CTL];track_render(t,out,CTL);for(unsigned i=0;i<CTL;i++)energy+=(double)out[i]*out[i];}return energy;}
int main(int argc,char**argv){ui_power_on();fm6_init();power_on_parts();trks_put(1);song.playing=0;int bad=0;
 if(argc==1){
 track_t *legacy=setup(0);legacy->p[P_ATK]=legacy->p[P_DEC]=legacy->p[P_SUS]=legacy->p[P_REL]=0;project_capture(&proj_scratch);if(project_restore_runtime(&proj_scratch)||trk[0].p[P_SUS]!=127||trk[0].p[P_REL]!=64){puts("FAIL legacy LXR placeholder compatibility");bad++;}
 legacy=setup(0);legacy->p[P_ATK]=5;legacy->p[P_DEC]=22;legacy->p[P_SUS]=63;legacy->p[P_REL]=17;project_capture(&proj_scratch);if(project_restore_runtime(&proj_scratch)||trk[0].p[P_ATK]!=5||trk[0].p[P_DEC]!=22||trk[0].p[P_SUS]!=63||trk[0].p[P_REL]!=17){puts("FAIL custom LXR ENV preservation");bad++;}
 printf("LXR saved ENV compatibility: failures=%d\n",bad);
 unsigned promoted=0;
 for(unsigned pi=0;pi<ENGINES[ENGI_HYDRA]->npresets;pi++){
 track_t*t=&trk[0];set_engine_of(t,ENGI_HYDRA);apply_preset_to(t,pi);t->engine=t->eng_req;t->xf=t->xf_on=t->xin=0;memset(t->v,0,sizeof t->v);t->nmono=0;t->p[P_VOICE]=V_LEGATO;
 trk_note_on(t,36,100);int32_t samples[CTL];for(unsigned i=0;i<50;i++)track_render(t,samples,CTL);trk_note_on(t,96,100);for(unsigned i=0;i<50;i++)track_render(t,samples,CTL);
 unsigned expected=jh_needs_os(&hy_part(0)->b,96*16);if(expected&&!jh_voice(t)->os){printf("FAIL HYDRA legato preset %u\n",pi);bad++;}if(expected)promoted++;
 trk_note_on(t,36,100);track_render(t,samples,CTL);if(expected&&!jh_voice(t)->os){printf("FAIL HYDRA descending stability %u\n",pi);bad++;}
 }
 printf("HYDRA low-to-high legato: %u promoted, failures=%d\n",promoted,bad);
for(unsigned p=0;p<LXR_COUNT;p++){track_t*t=setup(p);t->p[P_REL]=0;t->p[P_E2]=127;trk_note_on(t,60,100);int32_t out[CTL];for(unsigned b=0;b<8;b++)track_render(t,out,CTL);trk_note_off(t,60);for(unsigned b=0;b<160;b++)track_render(t,out,CTL);for(unsigned i=0;i<NVOICE;i++)if(t->v[i].active){printf("FAIL release preset %u\n",p);bad++;break;}}
 printf("LXR %u presets: short release terminates voices, failures=%d\n",LXR_COUNT,bad);
 double fast=render_env(0,127,127),slow=render_env(127,127,127),closed=render_env(0,127,0);printf("ENV attack energy fast=%.0f slow=%.0f; FILTER open=%.0f closed=%.0f\n",fast,slow,fast,closed);if(!(fast>slow*4&&fast>closed*2))bad++;
 return bad?1:0;}
 unsigned fx=atoi(argv[1]);track_t*t=setup(0);for(unsigned k=1;k<NTRK;k++){set_engine_of(&trk[k],ENGI_EMPTY);trk[k].engine=trk[k].eng_req;}t->p[P_E2]=127;t->p[P_REL]=0;if(fx)t->p[P_DIST+fx-1]=100;song.master_q12=4096;panic_req=0;FILE*f=fopen(argv[2],"wb");trk_note_on(t,60,110);for(unsigned b=0;b<3000;b++){if(b==100)trk_note_off(t,60);int32_t out[64];mix_block(out,32);fwrite(out,sizeof out,1,f);}fclose(f);return 0;}
