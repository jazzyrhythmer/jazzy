/* SPDX-License-Identifier: GPL-3.0-only */
#include <stdio.h>
#include <stdlib.h>
#include "../firmware/src/smk_controls.h"
static void ok(int v,const char*s){if(!v){fprintf(stderr,"FAIL %s\n",s);exit(1);}}
int main(void){smk_pickup_t p={0};int v;
 ok(smk_pickup(&p,0,0,0,100)==-1,"initial reading ignored");
 for(v=1;v<99;v++)ok(smk_pickup(&p,0,0,(uint8_t)v,100)==-1,"no value jump");
 ok(smk_pickup(&p,0,0,100,100)==100,"pickup at crossing");
 ok(smk_pickup(&p,0,0,110,100)==110,"fader follows after pickup");
 ok(smk_pickup(&p,0,0,111,20)==-1,"external edit re-arms pickup");
 ok(smk_pickup(&p,1,0,100,20)==-1,"bank change ignored");
 ok(smk_pickup(&p,1,0,50,20)==-1,"new bank unchanged until crossing");
 ok(smk_pickup(&p,1,0,10,20)==10,"pickup downwards");
 ok(smk_pickup(&p,2,0,10,100)==-1,"track window change re-arms");
 for(v=0;v<37;v++){uint32_t k=v<5?smk_outer_logical(v):v>31?smk_outer_logical(v):(uint32_t)v-5;ok(smk_key_offset(k)+53==48+v,"all 37 key pitches");}
 ok(smk_pickup(&p,0,4,0,0)==-1,"invalid fader rejected");
 puts("SMK_CONTROLS_PASS: pickup both directions, bank/track/external edits, all 37 key offsets");return 0;}
